// ================================================================
// admin.js — Painel do Proprietário (AID Group)
// ================================================================
const Admin = (() => {
    const db = () => window.SUPABASE_CONFIG.client;

    async function render() {
        if (!Auth.isOwner()) {
            document.getElementById('mainContent').innerHTML = UI.errorPage('Acesso reservado ao proprietário da plataforma.');
            return;
        }
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const [{ count: totalUsers }, { count: totalMerchants }, { count: totalProducts }, { count: totalOrders }, { data: recentFees }, { data: recentDisputes }] = await Promise.all([
                db().from('users').select('*', { count: 'exact', head: true }),
                db().from('merchants').select('*', { count: 'exact', head: true }),
                db().from('products').select('*', { count: 'exact', head: true }).eq('status', 'active'),
                db().from('orders').select('*', { count: 'exact', head: true }),
                db().from('platform_fees').select('*, merchant:merchant_id(name)').order('created_at', { ascending: false }).limit(10),
                db().from('disputes').select('*, user:user_id(name)').eq('status', 'open').order('created_at', { ascending: false }).limit(5)
            ]);

            const totalFeesPending   = (recentFees||[]).filter(f => f.status === 'pending').reduce((s,f) => s+(f.amount||0), 0);
            const totalFeesConfirmed = (recentFees||[]).filter(f => f.status === 'confirmed').reduce((s,f) => s+(f.amount||0), 0);

            c.innerHTML = `
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;">
                <div style="width:40px;height:40px;background:var(--blue);border-radius:10px;display:flex;align-items:center;justify-content:center;color:white;">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div>
                    <h2 style="font-weight:700;">Painel AID Group</h2>
                    <p class="text-xs text-muted">Acesso exclusivo do proprietário</p>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
                ${stat('fas fa-users',         'Utilizadores',  totalUsers||0,     'var(--blue)')}
                ${stat('fas fa-store',         'Comerciantes',  totalMerchants||0, 'var(--green)')}
                ${stat('fas fa-box',           'Produtos',      totalProducts||0,  'var(--orange)')}
                ${stat('fas fa-shopping-bag',  'Pedidos',       totalOrders||0,    'var(--blue-dark)')}
            </div>

            <div class="card mb-3">
                <p class="section-title">Taxas de Plataforma</p>
                <div class="flex-between mb-2">
                    <span class="text-muted text-sm">A aguardar confirmação</span>
                    <span class="font-bold text-orange">${UI.currency(totalFeesPending)}</span>
                </div>
                <div class="flex-between">
                    <span class="text-muted text-sm">Confirmadas (últimos 10)</span>
                    <span class="font-bold text-green">${UI.currency(totalFeesConfirmed)}</span>
                </div>
            </div>

            <div class="card mb-3">
                <div class="flex-between mb-3">
                    <p class="section-title" style="margin:0;">Taxas Recentes</p>
                </div>
                ${(recentFees||[]).length ? (recentFees||[]).map(f => `
                <div class="card mb-2" style="padding:12px;">
                    <div class="flex-between mb-2">
                        <div>
                            <p style="font-weight:600;font-size:.85rem;">${UI.esc(f.merchant?.name || 'Comerciante')}</p>
                            <p class="text-xs text-muted">${UI.dateStr(f.created_at)}</p>
                        </div>
                        <div style="text-align:right;">
                            <p class="font-bold text-blue">${UI.currency(f.amount)}</p>
                            <span class="status status-${f.status === 'confirmed' ? 'confirmed' : f.status === 'rejected' ? 'cancelled' : 'pending'}">
                                ${f.status === 'confirmed' ? 'Confirmado' : f.status === 'rejected' ? 'Rejeitado' : 'Pendente'}
                            </span>
                        </div>
                    </div>
                    ${f.image_url ? `<img src="${f.image_url}" style="width:100%;border-radius:8px;cursor:pointer;max-height:160px;object-fit:cover;" onclick="UI.modal({title:'Comprovante',body:'<img src=\'${f.image_url}\' style=\'width:100%;border-radius:8px;\'>'})" >` : ''}
                    ${f.caption ? `<p class="text-sm mt-2">${UI.esc(f.caption)}</p>` : ''}
                    ${f.status === 'pending' ? `
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px;">
                        <button class="btn btn-success btn-sm" onclick="Admin.confirmFee('${f.id}','confirmed')">
                            <i class="fas fa-check"></i> Confirmar
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="Admin.confirmFee('${f.id}','rejected')">
                            <i class="fas fa-times"></i> Rejeitar
                        </button>
                    </div>` : ''}
                </div>`).join('')
                : '<p class="text-muted text-sm">Sem taxas recentes</p>'}
            </div>

            <div class="card mb-3">
                <p class="section-title">Reclamações Abertas</p>
                ${(recentDisputes||[]).length ? (recentDisputes||[]).map(d => `
                <div class="card mb-2" style="padding:12px;cursor:pointer;" onclick="Admin.resolveDispute('${d.id}')">
                    <div class="flex-between">
                        <div>
                            <p style="font-weight:600;font-size:.85rem;">${UI.esc(d.subject || 'Reclamação')}</p>
                            <p class="text-xs text-muted">${UI.esc(d.user?.name || 'Utilizador')} • ${UI.dateStr(d.created_at)}</p>
                        </div>
                        <span class="status status-pending">Aberta</span>
                    </div>
                    ${d.description ? `<p class="text-sm mt-2 text-muted">${UI.esc(d.description.slice(0,100))}…</p>` : ''}
                </div>`).join('')
                : '<p class="text-muted text-sm">Sem reclamações abertas</p>'}
            </div>

            <div class="card">
                <p class="section-title">Acções Rápidas</p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                    <button class="btn btn-secondary btn-sm" onclick="Admin.renderAllUsers()">
                        <i class="fas fa-users"></i> Utilizadores
                    </button>
                    <button class="btn btn-secondary btn-sm" onclick="Admin.renderAllOrders()">
                        <i class="fas fa-shopping-bag"></i> Todos os pedidos
                    </button>
                    <button class="btn btn-secondary btn-sm" onclick="Admin.renderSettings()">
                        <i class="fas fa-cog"></i> Configurações
                    </button>
                    <button class="btn btn-secondary btn-sm" onclick="Admin.renderAllDisputes()">
                        <i class="fas fa-gavel"></i> Reclamações
                    </button>
                </div>
            </div>`;
        } catch(e) { c.innerHTML = UI.errorPage('Erro ao carregar painel'); }
    }

    function stat(icon, label, value, color) {
        return `
        <div class="card" style="text-align:center;padding:14px;">
            <i class="${icon}" style="font-size:1.3rem;color:${color};margin-bottom:6px;display:block;"></i>
            <p class="text-xs text-muted">${label}</p>
            <p style="font-weight:700;font-size:1.1rem;color:${color};">${value}</p>
        </div>`;
    }

    async function confirmFee(id, status) {
        UI.showLoading('A processar…');
        try {
            await db().from('platform_fees').update({ status, confirmed_at: new Date().toISOString() }).eq('id', id);
            UI.toast(status === 'confirmed' ? 'Taxa confirmada!' : 'Taxa rejeitada', status === 'confirmed' ? 'success' : 'warning');
            render();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    async function resolveDispute(id) {
        UI.modal({
            id: 'resolveModal',
            title: 'Resolver Reclamação',
            body: `
                <div class="form-group">
                    <label class="form-label">Decisão</label>
                    <select id="disputeStatus" class="form-input">
                        <option value="resolved">Resolvida — favorável ao cliente</option>
                        <option value="rejected">Rejeitada — sem fundamento</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Resolução / Explicação</label>
                    <textarea id="disputeResolution" class="form-input" placeholder="Descreva a decisão tomada…"></textarea>
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal('resolveModal')">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Admin._submitDispute('${id}')">Confirmar</button>`
        });
    }

    async function _submitDispute(id) {
        const status     = document.getElementById('disputeStatus')?.value;
        const resolution = document.getElementById('disputeResolution')?.value?.trim();
        if (!resolution) return UI.toast('Insira a resolução', 'warning');
        UI.showLoading('A resolver…');
        try {
            await db().from('disputes').update({ status, resolution, resolved_at: new Date().toISOString() }).eq('id', id);
            UI.closeModal('resolveModal');
            UI.toast('Reclamação resolvida!', 'success');
            render();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    async function renderAllUsers() {
        if (!Auth.isOwner()) return;
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        const { data: users } = await db().from('users').select('*').order('created_at', { ascending: false });
        c.innerHTML = `
        <button class="btn btn-secondary btn-sm mb-3" onclick="Admin.render()"><i class="fas fa-arrow-left"></i> Voltar</button>
        <h2 class="page-title">Todos os Utilizadores (${(users||[]).length})</h2>
        ${(users||[]).map(u => `
        <div class="card mb-2">
            <div class="flex-between">
                <div style="display:flex;gap:10px;align-items:center;">
                    ${UI.avatarHtml(u.avatar_url, u.name, 'avatar-sm')}
                    <div>
                        <p style="font-weight:600;font-size:.88rem;">${UI.esc(u.name)}</p>
                        <p class="text-xs text-muted">${u.user_type === 'merchant' ? 'Comerciante' : u.user_type === 'owner' ? 'Proprietário' : 'Cliente'} • ${UI.dateStr(u.created_at)}</p>
                    </div>
                </div>
                <select onchange="Admin.changeUserType('${u.id}',this.value)" class="form-input" style="width:auto;padding:4px 8px;font-size:.75rem;">
                    <option value="customer"  ${u.user_type==='customer'  ? 'selected':''}>Cliente</option>
                    <option value="merchant"  ${u.user_type==='merchant'  ? 'selected':''}>Comerciante</option>
                    <option value="owner"     ${u.user_type==='owner'     ? 'selected':''}>Proprietário</option>
                </select>
            </div>
        </div>`).join('')}`;
    }

    async function changeUserType(userId, type) {
        try {
            await db().from('users').update({ user_type: type }).eq('id', userId);
            if (type === 'merchant') {
                await db().from('merchants').upsert({ id: userId }, { onConflict: 'id' });
            }
            UI.toast('Tipo de conta actualizado', 'success');
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
    }

    async function renderAllOrders() {
        if (!Auth.isOwner()) return;
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        const { data: orders } = await db().from('orders').select('*, user:user_id(name)').order('created_at', { ascending: false }).limit(50);
        const statusMap = { pending:'Pendente', confirmed:'Confirmado', shipped:'Enviado', delivered:'Entregue', completed:'Concluído', cancelled:'Cancelado', payment_sent:'Pagamento enviado' };
        c.innerHTML = `
        <button class="btn btn-secondary btn-sm mb-3" onclick="Admin.render()"><i class="fas fa-arrow-left"></i> Voltar</button>
        <h2 class="page-title">Todos os Pedidos</h2>
        ${(orders||[]).map(o => `
        <div class="card mb-2">
            <div class="flex-between">
                <div>
                    <p style="font-weight:600;font-size:.85rem;">${UI.esc(o.order_number || o.id.slice(0,8))}</p>
                    <p class="text-xs text-muted">${UI.esc(o.user?.name || 'Cliente')} • ${UI.dateStr(o.created_at)}</p>
                </div>
                <div style="text-align:right;">
                    <p class="font-bold">${UI.currency(o.total_amount)}</p>
                    <span class="status status-${['confirmed','delivered','completed'].includes(o.status)?'confirmed':o.status==='cancelled'?'cancelled':'pending'}">
                        ${statusMap[o.status]||o.status}
                    </span>
                </div>
            </div>
        </div>`).join('')}`;
    }

    async function renderAllDisputes() {
        if (!Auth.isOwner()) return;
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        const { data: disputes } = await db().from('disputes').select('*, user:user_id(name)').order('created_at', { ascending: false });
        c.innerHTML = `
        <button class="btn btn-secondary btn-sm mb-3" onclick="Admin.render()"><i class="fas fa-arrow-left"></i> Voltar</button>
        <h2 class="page-title">Reclamações</h2>
        ${(disputes||[]).map(d => `
        <div class="card mb-2" ${d.status==='open'?`onclick="Admin.resolveDispute('${d.id}')" style="cursor:pointer;"`:''}>
            <div class="flex-between mb-1">
                <p style="font-weight:600;font-size:.85rem;">${UI.esc(d.subject||'Reclamação')}</p>
                <span class="status status-${d.status==='resolved'?'confirmed':d.status==='rejected'?'cancelled':'pending'}">
                    ${d.status==='resolved'?'Resolvida':d.status==='rejected'?'Rejeitada':'Aberta'}
                </span>
            </div>
            <p class="text-xs text-muted">${UI.esc(d.user?.name||'Utilizador')} • ${UI.dateStr(d.created_at)}</p>
            ${d.resolution?`<p class="text-sm mt-2 text-muted">${UI.esc(d.resolution)}</p>`:''}
        </div>`).join('') || UI.emptyState('fas fa-gavel','Sem reclamações','','')}`;
    }

    async function renderSettings() {
        if (!Auth.isOwner()) return;
        UI.modal({
            title: 'Configurações da Plataforma',
            body: `
                <div class="form-group">
                    <label class="form-label">Taxa de plataforma (%)</label>
                    <input type="number" id="settingsTax" class="form-input" value="${(window.SUPABASE_CONFIG.TAX_RATE||0.05)*100}" min="0" max="100" step="0.5">
                    <p class="form-hint">Percentagem cobrada ao comerciante por venda</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Nome da organização</label>
                    <input type="text" id="settingsOrg" class="form-input" value="${window.SUPABASE_CONFIG.ORG_NAME||'AID Group'}">
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal()">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Admin._saveSettings()">Guardar</button>`
        });
    }

    function _saveSettings() {
        const tax = parseFloat(document.getElementById('settingsTax')?.value) / 100;
        const org = document.getElementById('settingsOrg')?.value?.trim();
        if (tax >= 0 && tax <= 1) window.SUPABASE_CONFIG.TAX_RATE = tax;
        if (org) window.SUPABASE_CONFIG.ORG_NAME = org;
        UI.closeModal();
        UI.toast('Configurações guardadas nesta sessão', 'success');
    }

    return { render, confirmFee, resolveDispute, _submitDispute, renderAllUsers, changeUserType, renderAllOrders, renderAllDisputes, renderSettings, _saveSettings };
})();

window.Admin = Admin;
