// ================================================================
// auth.js — Autenticação + Perfil
// ================================================================
const Auth = (() => {
    const db = () => window.SUPABASE_CONFIG.client;
    let _session = null;
    let _profile = null;

    // ── INICIALIZAR ───────────────────────────────────────────
    async function init() {
        try {
            const { data: { session } } = await db().auth.getSession();
            _session = session;
            if (session) await _loadProfile(session.user.id);
            db().auth.onAuthStateChange(async (event, session) => {
                _session = session;
                if (session) await _loadProfile(session.user.id);
                else { _profile = null; _updateDrawer(); }
                if (event === 'SIGNED_IN')  App.navigate('home');
                if (event === 'SIGNED_OUT') App.navigate('home');
            });
            _updateDrawer();
        } catch(e) { console.warn('[Auth.init]', e?.message); }
    }

    async function _loadProfile(uid) {
        try {
            const { data } = await db().from('users').select('*').eq('id', uid).single();
            _profile = data;
            _updateDrawer();
        } catch(e) {}
    }

    function _updateDrawer() {
        const nameEl = document.getElementById('drawerUserName');
        const typeEl = document.getElementById('drawerUserType');
        const avatarEl = document.getElementById('drawerAvatar');
        const typeLabelMap = { customer: 'Cliente', merchant: 'Comerciante', owner: 'Proprietário' };

        if (_profile && nameEl) {
            nameEl.textContent = _profile.name || 'Utilizador';
            if (typeEl) typeEl.textContent = typeLabelMap[_profile.user_type] || 'Cliente';
            if (avatarEl) avatarEl.innerHTML = UI.avatarHtml(_profile.avatar_url, _profile.name, 'avatar-md');
        } else if (nameEl) {
            nameEl.textContent = 'Visitante';
            if (typeEl) typeEl.textContent = 'Entrar / Registar';
        }

        // Mostrar/esconder itens do menu por tipo
        const isMerchant = _profile?.user_type === 'merchant';
        const isOwner    = _profile?.user_type === 'owner';
        ['sectionMerchant','menuMyProducts','menuReports','menuFee'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = isMerchant || isOwner ? '' : 'none';
        });
        ['sectionOwner','menuAdmin'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = isOwner ? '' : 'none';
        });
    }

    // ── RENDER LOGIN ──────────────────────────────────────────
    function renderLogin() {
        document.getElementById('mainContent').innerHTML = `
        <div style="max-width:400px;margin:0 auto;padding-top:20px;">
            <div class="text-center mb-4">
                <div style="width:64px;height:64px;background:var(--blue);border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:1.8rem;color:white;font-weight:700;">A</div>
                <h2 style="font-size:1.3rem;font-weight:700;">Bem-vindo ao Mercado AID</h2>
                <p class="text-muted text-sm mt-2">Entre ou crie a sua conta para continuar</p>
            </div>
            <div class="tabs">
                <button class="tab-btn active" id="tabLogin" onclick="Auth._showTab('login')">Entrar</button>
                <button class="tab-btn" id="tabRegister" onclick="Auth._showTab('register')">Registar</button>
            </div>

            <!-- LOGIN -->
            <div id="formLogin" class="card">
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" id="loginEmail" class="form-input" placeholder="o-seu@email.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Senha</label>
                    <input type="password" id="loginPass" class="form-input" placeholder="••••••••">
                </div>
                <button class="btn btn-primary mt-2" onclick="Auth.login()">
                    <i class="fas fa-sign-in-alt"></i> Entrar
                </button>
                <button class="btn btn-secondary mt-2" onclick="Auth._showForgot()">
                    Esqueci a senha
                </button>
            </div>

            <!-- REGISTO -->
            <div id="formRegister" class="card" style="display:none">
                <div class="form-group">
                    <label class="form-label">Nome completo</label>
                    <input type="text" id="regName" class="form-input" placeholder="O seu nome">
                </div>
                <div class="form-group">
                    <label class="form-label">Telefone</label>
                    <input type="tel" id="regPhone" class="form-input" placeholder="84 XXX XXXX">
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" id="regEmail" class="form-input" placeholder="o-seu@email.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Senha</label>
                    <input type="password" id="regPass" class="form-input" placeholder="Mínimo 6 caracteres">
                </div>
                <div class="form-group">
                    <label class="form-label">Tipo de conta</label>
                    <select id="regType" class="form-input">
                        <option value="customer">Cliente</option>
                        <option value="merchant">Comerciante</option>
                    </select>
                </div>
                <button class="btn btn-primary mt-2" onclick="Auth.register()">
                    <i class="fas fa-user-plus"></i> Criar conta
                </button>
            </div>
        </div>`;
    }

    function _showTab(tab) {
        document.getElementById('formLogin').style.display    = tab === 'login'    ? '' : 'none';
        document.getElementById('formRegister').style.display = tab === 'register' ? '' : 'none';
        document.getElementById('tabLogin').classList.toggle('active',    tab === 'login');
        document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
    }

    function _showForgot() {
        UI.modal({
            title: 'Recuperar Senha',
            body: `
                <p class="text-sm text-muted mb-3">Insira o seu email e enviaremos um link de recuperação.</p>
                <input type="email" id="forgotEmail" class="form-input" placeholder="o-seu@email.com">`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal()">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Auth.forgotPassword()">Enviar</button>`
        });
    }

    // ── ACÇÕES ────────────────────────────────────────────────
    async function login() {
        const email = document.getElementById('loginEmail')?.value?.trim();
        const pass  = document.getElementById('loginPass')?.value;
        if (!email || !pass) return UI.toast('Preencha todos os campos', 'warning');
        UI.showLoading('A entrar…');
        try {
            const { error } = await db().auth.signInWithPassword({ email, password: pass });
            if (error) throw error;
            UI.toast('Sessão iniciada com sucesso!', 'success');
        } catch(e) {
            UI.toast('Credenciais inválidas. Verifique o email e a senha.', 'error');
        } finally { UI.hideLoading(); }
    }

    async function register() {
        const name  = document.getElementById('regName')?.value?.trim();
        const phone = document.getElementById('regPhone')?.value?.trim();
        const email = document.getElementById('regEmail')?.value?.trim();
        const pass  = document.getElementById('regPass')?.value;
        const type  = document.getElementById('regType')?.value;
        if (!name || !email || !pass) return UI.toast('Preencha todos os campos obrigatórios', 'warning');
        if (pass.length < 6) return UI.toast('A senha deve ter pelo menos 6 caracteres', 'warning');
        UI.showLoading('A criar conta…');
        try {
            const { error } = await db().auth.signUp({
                email, password: pass,
                options: { data: { name, phone, user_type: type }, emailRedirectTo: window.location.origin }
            });
            if (error) throw error;
            UI.toast('Conta criada! Pode entrar agora.', 'success');
            _showTab('login');
        } catch(e) {
            UI.toast(e.message || 'Erro ao criar conta', 'error');
        } finally { UI.hideLoading(); }
    }

    async function forgotPassword() {
        const email = document.getElementById('forgotEmail')?.value?.trim();
        if (!email) return UI.toast('Insira o seu email', 'warning');
        UI.showLoading('A enviar…');
        try {
            const { error } = await db().auth.resetPasswordForEmail(email, {
                redirectTo: window.location.origin + '/reset-password.html'
            });
            if (error) throw error;
            UI.closeModal();
            UI.toast('Email de recuperação enviado!', 'success');
        } catch(e) {
            UI.toast(e.message || 'Erro ao enviar email', 'error');
        } finally { UI.hideLoading(); }
    }

    async function logout() {
        UI.confirm('Tem a certeza que quer sair?', async () => {
            UI.showLoading('A sair…');
            await db().auth.signOut();
            Storage.clear();
            UI.hideLoading();
            UI.toast('Sessão terminada', 'info');
        });
    }

    // ── RENDER PERFIL ─────────────────────────────────────────
    async function renderProfile() {
        if (!_session) return renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:40vh;"><div class="spinner"></div></div>`;
        try {
            const { data: p } = await db().from('users').select('*').eq('id', _session.user.id).single();
            _profile = p;
            c.innerHTML = `
            <div style="max-width:500px;margin:0 auto;">
                <div class="card text-center mb-3">
                    <div style="position:relative;display:inline-block;margin-bottom:12px;">
                        ${UI.avatarHtml(p.avatar_url, p.name, 'avatar-xl')}
                        <button onclick="Auth._changeAvatar()" style="position:absolute;bottom:0;right:0;width:28px;height:28px;border-radius:50%;background:var(--blue);border:none;color:white;cursor:pointer;font-size:.75rem;">
                            <i class="fas fa-camera"></i>
                        </button>
                    </div>
                    <h2 style="font-weight:700;">${UI.esc(p.name)}</h2>
                    <p class="text-muted text-sm">${_session.user.email}</p>
                    <span class="status status-active mt-2" style="display:inline-flex;">
                        ${p.user_type === 'merchant' ? '<i class="fas fa-store"></i> Comerciante' : p.user_type === 'owner' ? '<i class="fas fa-crown"></i> Proprietário' : '<i class="fas fa-user"></i> Cliente'}
                    </span>
                </div>

                <div class="card mb-3">
                    <p class="section-title">Dados Pessoais</p>
                    <div class="form-group">
                        <label class="form-label">Nome</label>
                        <input type="text" id="pName" class="form-input" value="${UI.esc(p.name||'')}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Telefone</label>
                        <input type="tel" id="pPhone" class="form-input" value="${UI.esc(p.phone||'')}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Localização</label>
                        <input type="text" id="pLocation" class="form-input" placeholder="Cidade, Bairro" value="${UI.esc(p.location||'')}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Especialidade / Profissão</label>
                        <input type="text" id="pSpecialty" class="form-input" placeholder="Ex: Electricista, Costureira…" value="${UI.esc(p.specialty||'')}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sobre mim</label>
                        <textarea id="pBio" class="form-input" placeholder="Uma breve descrição sobre si…">${UI.esc(p.bio||'')}</textarea>
                    </div>
                    <button class="btn btn-primary" onclick="Auth.saveProfile()">
                        <i class="fas fa-save"></i> Guardar alterações
                    </button>
                </div>

                ${p.user_type === 'customer' ? `
                <div class="card">
                    <p class="section-title">Tornar-se Comerciante</p>
                    <p class="text-sm text-muted mb-3">Venda os seus produtos no Mercado AID e alcance mais clientes.</p>
                    <button class="btn btn-success" onclick="Auth.becomeMerchant()">
                        <i class="fas fa-store"></i> Activar conta de comerciante
                    </button>
                </div>` : ''}

                <div class="card mt-3">
                    <button class="btn btn-danger" onclick="Auth.logout()">
                        <i class="fas fa-sign-out-alt"></i> Sair da conta
                    </button>
                </div>
            </div>`;
        } catch(e) {
            c.innerHTML = UI.errorPage('Erro ao carregar perfil');
        }
    }

    async function saveProfile() {
        const upd = {
            name     : document.getElementById('pName')?.value?.trim(),
            phone    : document.getElementById('pPhone')?.value?.trim(),
            location : document.getElementById('pLocation')?.value?.trim(),
            specialty: document.getElementById('pSpecialty')?.value?.trim(),
            bio      : document.getElementById('pBio')?.value?.trim()
        };
        if (!upd.name) return UI.toast('O nome é obrigatório', 'warning');
        UI.showLoading('A guardar…');
        try {
            const { error } = await db().from('users').update(upd).eq('id', _session.user.id);
            if (error) throw error;
            _profile = { ..._profile, ...upd };
            _updateDrawer();
            UI.toast('Perfil actualizado!', 'success');
        } catch(e) {
            UI.toast('Erro ao guardar: ' + e.message, 'error');
        } finally { UI.hideLoading(); }
    }

    async function _changeAvatar() {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = 'image/*';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            if (file.size > 5 * 1024 * 1024) return UI.toast('Imagem muito grande (máx. 5MB)', 'warning');
            UI.showLoading('A enviar foto…');
            try {
                const ext  = file.name.split('.').pop();
                const path = `${_session.user.id}/avatar.${ext}`;
                const { error: upErr } = await db().storage.from('profile-images').upload(path, file, { upsert: true });
                if (upErr) throw upErr;
                const { data: { publicUrl } } = db().storage.from('profile-images').getPublicUrl(path);
                const { error } = await db().from('users').update({ avatar_url: publicUrl }).eq('id', _session.user.id);
                if (error) throw error;
                _profile.avatar_url = publicUrl;
                _updateDrawer();
                UI.toast('Foto actualizada!', 'success');
                renderProfile();
            } catch(e) {
                UI.toast('Erro ao enviar foto: ' + e.message, 'error');
            } finally { UI.hideLoading(); }
        };
        input.click();
    }

    async function becomeMerchant() {
        UI.confirm('Deseja activar a conta de comerciante?', async () => {
            UI.showLoading('A activar…');
            try {
                await db().from('users').update({ user_type: 'merchant' }).eq('id', _session.user.id);
                await db().from('merchants').insert({ id: _session.user.id, store_name: _profile.name + ' — Loja' });
                _profile.user_type = 'merchant';
                _updateDrawer();
                UI.toast('Conta de comerciante activada!', 'success');
                renderProfile();
            } catch(e) {
                UI.toast('Erro: ' + e.message, 'error');
            } finally { UI.hideLoading(); }
        });
    }

    // ── GETTERS ───────────────────────────────────────────────
    function getSession()  { return _session; }
    function getProfile()  { return _profile; }
    function isLoggedIn()  { return !!_session; }
    function isMerchant()  { return _profile?.user_type === 'merchant' || _profile?.user_type === 'owner'; }
    function isOwner()     { return _profile?.user_type === 'owner'; }

    return { init, login, register, forgotPassword, logout, renderLogin, renderProfile, saveProfile, becomeMerchant, _showTab, _showForgot, _changeAvatar, getSession, getProfile, isLoggedIn, isMerchant, isOwner };
})();

window.Auth = Auth;
