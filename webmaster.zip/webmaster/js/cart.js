// ================================================================
// cart.js — Carrinho de compras
// ================================================================
const Cart = (() => {
    const db = () => window.SUPABASE_CONFIG.client;
    let _items = [];

    async function load() {
        try {
            if (!Auth.isLoggedIn()) { _items = Storage.get('cart', []); _updateBadge(); return; }
            const { data } = await db().from('cart').select('*, products(*, product_images(*))').eq('user_id', Auth.getSession().user.id);
            _items = data || [];
            _updateBadge();
        } catch(e) { _items = []; }
    }

    function _updateBadge() {
        const total = _items.reduce((s, i) => s + (i.quantity || 1), 0);
        const badge = document.getElementById('cartBadge');
        if (badge) { badge.textContent = total; badge.classList.toggle('show', total > 0); }
    }

    async function add(productId, name, price) {
        if (!Auth.isLoggedIn()) return UI.toast('Entre na sua conta para adicionar ao carrinho', 'warning');
        UI.showLoading('A adicionar…');
        try {
            const uid = Auth.getSession().user.id;
            const { error } = await db().from('cart').upsert({ user_id: uid, product_id: productId, quantity: 1 }, { onConflict: 'user_id,product_id' });
            if (error) throw error;
            await load();
            UI.toast(`"${name}" adicionado ao carrinho!`, 'success');
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    async function remove(productId) {
        if (!Auth.isLoggedIn()) return;
        try {
            await db().from('cart').delete().eq('user_id', Auth.getSession().user.id).eq('product_id', productId);
            await load();
            render();
        } catch(e) { UI.toast('Erro ao remover', 'error'); }
    }

    async function updateQty(productId, qty) {
        if (qty < 1) return remove(productId);
        try {
            await db().from('cart').update({ quantity: qty }).eq('user_id', Auth.getSession().user.id).eq('product_id', productId);
            await load();
            render();
        } catch(e) {}
    }

    function getTotal() {
        return _items.reduce((s, i) => s + (i.quantity || 1) * (i.products?.price || 0), 0);
    }

    async function render() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        await load();

        if (!_items.length) {
            c.innerHTML = UI.emptyState('fas fa-shopping-cart', 'O seu carrinho está vazio.', 'Ir ao mercado', "App.navigate('market')");
            return;
        }

        c.innerHTML = `
        <h2 class="page-title">Carrinho (${_items.length})</h2>
        <div id="cartList">
        ${_items.map(item => {
            const p   = item.products || {};
            const img = (p.product_images || [])[0]?.image_url || '';
            return `
            <div class="cart-item">
                <div style="width:72px;height:72px;border-radius:8px;overflow:hidden;flex-shrink:0;background:var(--gray-100);">
                    ${img ? `<img src="${img}" class="cart-item-img">` : '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--gray-400);"><i class="fas fa-image"></i></div>'}
                </div>
                <div class="cart-item-info">
                    <p style="font-weight:600;font-size:.88rem;">${UI.esc(p.name || 'Produto')}</p>
                    <p class="text-blue font-bold">${UI.currency(p.price)}</p>
                    <div class="qty-controls">
                        <button class="qty-btn" onclick="Cart.updateQty('${item.product_id}', ${item.quantity - 1})">-</button>
                        <span style="font-weight:600;">${item.quantity}</span>
                        <button class="qty-btn" onclick="Cart.updateQty('${item.product_id}', ${item.quantity + 1})">+</button>
                        <button onclick="Cart.remove('${item.product_id}')" style="margin-left:auto;background:none;border:none;color:var(--red);cursor:pointer;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>`;
        }).join('')}
        </div>

        <div class="card mt-3">
            <div class="flex-between mb-2">
                <span class="text-muted">Subtotal</span>
                <span class="font-bold">${UI.currency(getTotal())}</span>
            </div>
            <div class="divider"></div>
            <div class="flex-between" style="font-size:1.1rem;">
                <span class="font-bold">Total</span>
                <span class="font-bold text-blue">${UI.currency(getTotal())}</span>
            </div>
            <button class="btn btn-primary mt-3" onclick="Cart.checkout()">
                <i class="fas fa-shopping-bag"></i> Finalizar compra
            </button>
        </div>`;
    }

    async function checkout() {
        if (!_items.length) return;
        UI.modal({
            title: 'Finalizar Compra',
            body: `
                <p class="text-sm text-muted mb-3">Total a pagar: <strong>${UI.currency(getTotal())}</strong></p>
                <div class="form-group">
                    <label class="form-label">Endereço de entrega *</label>
                    <textarea id="checkoutAddr" class="form-input" placeholder="Rua, Bairro, Cidade…"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Método de pagamento</label>
                    <select id="checkoutMethod" class="form-input">
                        <option value="mpesa">M-Pesa</option>
                        <option value="emola">e-Mola</option>
                        <option value="mcash">M-Cash</option>
                        <option value="bank">Transferência Bancária</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Notas adicionais</label>
                    <input type="text" id="checkoutNotes" class="form-input" placeholder="Instruções especiais…">
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal()">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Cart._confirmCheckout()">Confirmar pedido</button>`
        });
    }

    async function _confirmCheckout() {
        const addr   = document.getElementById('checkoutAddr')?.value?.trim();
        const method = document.getElementById('checkoutMethod')?.value;
        const notes  = document.getElementById('checkoutNotes')?.value?.trim();
        if (!addr) return UI.toast('Insira o endereço de entrega', 'warning');
        UI.closeModal();
        UI.showLoading('A processar pedido…');
        try {
            const uid      = Auth.getSession().user.id;
            const total    = getTotal();
            const fee      = total * (window.SUPABASE_CONFIG.TAX_RATE || 0.05);
            const merchant = _items[0]?.products?.merchant_id;

            const { data: order, error } = await db().from('orders').insert({
                user_id: uid, merchant_id: merchant,
                total_amount: total, platform_fee: fee,
                payment_method: method, shipping_address: addr, notes, status: 'pending'
            }).select().single();
            if (error) throw error;

            for (const item of _items) {
                await db().from('order_items').insert({
                    order_id: order.id, product_id: item.product_id,
                    product_name: item.products?.name || 'Produto',
                    quantity: item.quantity, unit_price: item.products?.price || 0
                });
            }

            await db().from('cart').delete().eq('user_id', uid);
            _items = [];
            _updateBadge();

            UI.toast('Pedido efectuado com sucesso!', 'success');
            App.navigate('orders');
        } catch(e) {
            UI.toast('Erro: ' + e.message, 'error');
        } finally { UI.hideLoading(); }
    }

    return { load, add, remove, updateQty, render, checkout, _confirmCheckout };
})();

window.Cart = Cart;
