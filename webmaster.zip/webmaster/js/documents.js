// ================================================================
// documents.js — Documentos pessoais
// ================================================================
const Documents = (() => {
    const db = () => window.SUPABASE_CONFIG.client;

    async function render() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data: docs } = await db().from('documents').select('*').eq('user_id', uid).order('created_at', { ascending: false });

            c.innerHTML = `
            <div class="flex-between mb-4">
                <h2 class="page-title" style="margin:0;">Os Meus Documentos</h2>
                <button class="btn btn-primary btn-sm" onclick="Documents.renderAdd()">
                    <i class="fas fa-plus"></i> Adicionar
                </button>
            </div>
            <div class="card mb-3" style="background:var(--orange-light);border:1.5px solid var(--orange);">
                <p style="font-size:.82rem;color:var(--orange);"><i class="fas fa-lock"></i> Os seus documentos são privados e apenas visíveis por si.</p>
            </div>
            ${(docs||[]).length ? (docs||[]).map(d => docCardHtml(d)).join('')
            : UI.emptyState('fas fa-folder-open', 'Sem documentos adicionados.', 'Adicionar documento', "Documents.renderAdd()")}`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    function docCardHtml(d) {
        const iconMap = { bi:'fa-id-card', nuit:'fa-file-invoice', license:'fa-certificate', other:'fa-file' };
        const labelMap = { bi:'Bilhete de Identidade', nuit:'NUIT', license:'Licença', other:'Outro' };
        const isImg = d.file_url && /\.(jpg|jpeg|png|gif|webp)$/i.test(d.file_url);
        return `
        <div class="card mb-2">
            <div style="display:flex;gap:12px;align-items:center;">
                <div style="width:48px;height:48px;border-radius:10px;background:var(--blue-light);display:flex;align-items:center;justify-content:center;color:var(--blue);flex-shrink:0;">
                    <i class="fas ${iconMap[d.document_type] || 'fa-file'}" style="font-size:1.3rem;"></i>
                </div>
                <div style="flex:1;min-width:0;">
                    <p style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${UI.esc(d.name)}</p>
                    <p class="text-sm text-muted">${labelMap[d.document_type] || 'Documento'}</p>
                    <p class="text-xs text-muted">${UI.dateStr(d.created_at)}</p>
                </div>
                <div style="display:flex;gap:6px;flex-shrink:0;">
                    <button class="btn btn-secondary btn-sm btn-icon" onclick="Documents.viewDoc('${d.file_url}','${UI.esc(d.name)}',${isImg})">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-danger btn-sm btn-icon" onclick="Documents.deleteDoc('${d.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>`;
    }

    function renderAdd() {
        UI.modal({
            id: 'addDocModal',
            title: 'Adicionar Documento',
            body: `
                <div class="form-group">
                    <label class="form-label">Nome do documento *</label>
                    <input type="text" id="docName" class="form-input" placeholder="Ex: BI de João Silva">
                </div>
                <div class="form-group">
                    <label class="form-label">Tipo</label>
                    <select id="docType" class="form-input">
                        <option value="bi">Bilhete de Identidade</option>
                        <option value="nuit">NUIT</option>
                        <option value="license">Licença</option>
                        <option value="other">Outro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Ficheiro (imagem ou PDF) *</label>
                    <input type="file" id="docFile" class="form-input" accept="image/*,.pdf">
                    <p class="form-hint">Máximo 10MB</p>
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal('addDocModal')">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Documents.saveDoc()">
                    <i class="fas fa-upload"></i> Guardar
                </button>`
        });
    }

    async function saveDoc() {
        const name = document.getElementById('docName')?.value?.trim();
        const type = document.getElementById('docType')?.value;
        const file = document.getElementById('docFile')?.files?.[0];
        if (!name) return UI.toast('Insira o nome do documento', 'warning');
        if (!file) return UI.toast('Seleccione um ficheiro', 'warning');
        if (file.size > 10 * 1024 * 1024) return UI.toast('Ficheiro muito grande (máx. 10MB)', 'warning');
        UI.showLoading('A guardar documento…');
        try {
            const uid  = Auth.getSession().user.id;
            const ext  = file.name.split('.').pop();
            const path = `docs/${uid}/${Date.now()}.${ext}`;
            const { error: upErr } = await db().storage.from('document-files').upload(path, file);
            if (upErr) throw upErr;
            const { data: { publicUrl } } = db().storage.from('document-files').getPublicUrl(path);
            const { error } = await db().from('documents').insert({ user_id: uid, name, document_type: type, file_url: publicUrl });
            if (error) throw error;
            UI.closeModal('addDocModal');
            UI.toast('Documento guardado!', 'success');
            render();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    function viewDoc(url, name, isImg) {
        if (isImg) {
            UI.modal({ title: name, body: `<img src="${url}" style="width:100%;border-radius:8px;">` });
        } else {
            window.open(url, '_blank');
        }
    }

    async function deleteDoc(id) {
        UI.confirm('Eliminar este documento?', async () => {
            try {
                await db().from('documents').delete().eq('id', id);
                UI.toast('Documento eliminado', 'success');
                render();
            } catch(e) { UI.toast('Erro ao eliminar', 'error'); }
        });
    }

    return { render, renderAdd, saveDoc, viewDoc, deleteDoc };
})();

window.Documents = Documents;
