// ================================================================
// main.js — Inicialização + Roteamento SPA
// ================================================================
const App = (() => {

    // ── RELÓGIO ───────────────────────────────────────────────
    function _startClock() {
        const el = document.getElementById('liveClock');
        if (!el) return;
        const update = () => {
            const now = new Date();
            el.textContent = now.toLocaleTimeString('pt-MZ', { hour: '2-digit', minute: '2-digit' });
        };
        update();
        setInterval(update, 1000);
    }

    // ── DRAWER ────────────────────────────────────────────────
    function _initDrawer() {
        const menuBtn   = document.getElementById('menuIcon');
        const overlay   = document.getElementById('drawerOverlay');
        const drawer    = document.getElementById('drawer');
        const closeBtn  = document.getElementById('drawerClose');
        const logoutBtn = document.getElementById('logoutBtn');

        const open  = () => { drawer?.classList.add('open'); overlay?.classList.add('show'); };
        const close = () => { drawer?.classList.remove('open'); overlay?.classList.remove('show'); };

        menuBtn?.addEventListener('click', open);
        overlay?.addEventListener('click', close);
        closeBtn?.addEventListener('click', close);
        logoutBtn?.addEventListener('click', () => { close(); Auth.logout(); });

        document.querySelectorAll('.drawer-menu li[data-route]').forEach(item => {
            item.addEventListener('click', () => {
                close();
                navigate(item.dataset.route);
            });
        });
    }

    // ── BOTTOM NAV ────────────────────────────────────────────
    function _initBottomNav() {
        document.querySelectorAll('.bottom-nav-item').forEach(item => {
            item.addEventListener('click', () => navigate(item.dataset.route));
        });

        document.getElementById('cartIcon')?.addEventListener('click',  () => navigate('cart'));
        document.getElementById('notifIcon')?.addEventListener('click', () => navigate('notifications'));
    }

    // ── ACTUALIZAR NAV ACTIVO ─────────────────────────────────
    function _setActiveNav(route) {
        const main = route.split('?')[0];
        document.querySelectorAll('.bottom-nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.route === main);
        });
    }

    // ── ROTEAMENTO ────────────────────────────────────────────
    async function navigate(route) {
        window.location.hash = route;
        await _renderPage(route);
    }

    async function _renderPage(route) {
        const [path, query] = route.split('?');
        _setActiveNav(path);
        const c = document.getElementById('mainContent');

        // Scroll ao topo
        c?.scrollTo?.(0, 0);
        window.scrollTo(0, 0);

        try {
            switch (path) {
                case 'home':
                case '':
                    await Products.renderHome();
                    break;

                case 'market':
                    await Products.renderMarket();
                    break;

                case 'product':
                    const pid = new URLSearchParams(query).get('id');
                    if (pid) await Products.renderDetail(pid);
                    else navigate('market');
                    break;

                case 'cart':
                    await Cart.render();
                    break;

                case 'orders':
                    await Orders.render();
                    break;

                case 'order-detail':
                    const oid = new URLSearchParams(query).get('id');
                    if (oid) await Orders.renderDetail(oid);
                    else navigate('orders');
                    break;

                case 'wallet':
                    await Wallet.render();
                    break;

                case 'platform-fee':
                    await Wallet.renderPlatformFee();
                    break;

                case 'profile':
                    await Auth.renderProfile();
                    break;

                case 'login':
                    Auth.renderLogin();
                    break;

                case 'my-products':
                    await Products.renderMyProducts();
                    break;

                case 'notifications':
                    await Notifications.render();
                    break;

                case 'messages':
                    await Messages.render();
                    break;

                case 'chat':
                    const chatUser = new URLSearchParams(query).get('user');
                    if (chatUser) Messages.startChat(null, chatUser);
                    else navigate('messages');
                    break;

                case 'documents':
                    await Documents.render();
                    break;

                case 'reports':
                    await Reports.render();
                    break;

                case 'admin':
                    await Admin.render();
                    break;

                case 'favorites':
                    await renderFavorites();
                    break;

                case 'contracts':
                    await renderContracts();
                    break;

                case 'disputes':
                    await renderDisputes();
                    break;

                case 'store':
                    const sid = new URLSearchParams(query).get('id');
                    if (sid) await renderStore(sid);
                    else navigate('market');
                    break;

                case 'about':
                    renderAbout();
                    break;

                case 'settings':
                    renderSettings();
                    break;

                default:
                    navigate('home');
            }
        } catch(e) {
            console.error('[App._renderPage] Erro:', e?.message, e?.stack);
            if (c) c.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-circle text-red"></i>
                    <p>Erro ao carregar a página</p>
                    <p class="text-xs text-muted mt-2">${UI.esc(e?.message || '')}</p>
                    <button class="btn btn-primary btn-sm mt-3" onclick="App.navigate('home')">Voltar ao início</button>
                </div>`;
        }
    }

    // ── FAVORITOS ─────────────────────────────────────────────
    async function renderFavorites() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data } = await window.SUPABASE_CONFIG.client.from('favorites')
                .select('*, products(*, product_images(*))')
                .eq('user_id', uid);
            c.innerHTML = `<h2 class="page-title">Favoritos</h2>`;
            if (!(data||[]).length) {
                c.innerHTML += UI.emptyState('far fa-heart', 'Sem produtos favoritos.', 'Explorar mercado', "App.navigate('market')");
                return;
            }
            const grid = document.createElement('div');
            grid.className = 'products-grid';
            grid.innerHTML = (data||[]).map(f => f.products ? Products.productCardHtml ? '' : `
                <div class="product-card card-hover" onclick="App.navigate('product?id=${f.products.id}')">
                    <div class="product-img">
                        ${(f.products.product_images||[])[0]?.image_url
                            ? `<img src="${(f.products.product_images||[])[0].image_url}" loading="lazy">`
                            : `<div class="product-img-placeholder"><i class="fas fa-image"></i></div>`}
                    </div>
                    <div class="product-info">
                        <div class="product-name">${UI.esc(f.products.name)}</div>
                        <div class="product-price">${UI.currency(f.products.price)}</div>
                    </div>
                </div>` : '').join('');
            c.appendChild(grid);
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    // ── CONTRATOS ─────────────────────────────────────────────
    async function renderContracts() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data } = await window.SUPABASE_CONFIG.client.from('contracts')
                .select('*').or(`user_id.eq.${uid},merchant_id.eq.${uid}`)
                .order('created_at', { ascending: false });
            c.innerHTML = `
            <h2 class="page-title">Contratos</h2>
            ${(data||[]).length ? (data||[]).map(ct => `
            <div class="card mb-2">
                <div class="flex-between mb-2">
                    <p style="font-weight:600;">${UI.esc(ct.terms?.slice(0,50) || 'Contrato')}…</p>
                    <span class="status ${ct.signed_by_user && ct.signed_by_merchant ? 'status-confirmed' : 'status-pending'}">
                        ${ct.signed_by_user && ct.signed_by_merchant ? 'Assinado' : 'Pendente'}
                    </span>
                </div>
                <p class="text-xs text-muted">${UI.dateStr(ct.created_at)}</p>
                ${!ct.signed_by_user && ct.user_id === uid ? `
                <button class="btn btn-primary btn-sm mt-2" onclick="App._signContract('${ct.id}')">
                    <i class="fas fa-signature"></i> Assinar
                </button>` : ''}
            </div>`).join('')
            : UI.emptyState('fas fa-file-signature', 'Sem contratos.', '', '')}`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    async function _signContract(id) {
        try {
            await window.SUPABASE_CONFIG.client.from('contracts')
                .update({ signed_by_user: true, signed_at: new Date().toISOString() }).eq('id', id);
            UI.toast('Contrato assinado!', 'success');
            renderContracts();
        } catch(e) { UI.toast('Erro ao assinar', 'error'); }
    }

    // ── RECLAMAÇÕES ───────────────────────────────────────────
    async function renderDisputes() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data } = await window.SUPABASE_CONFIG.client.from('disputes')
                .select('*').or(`user_id.eq.${uid},merchant_id.eq.${uid}`)
                .order('created_at', { ascending: false });
            c.innerHTML = `
            <div class="flex-between mb-4">
                <h2 class="page-title" style="margin:0;">Reclamações</h2>
                <button class="btn btn-primary btn-sm" onclick="App._newDispute()">
                    <i class="fas fa-plus"></i> Nova
                </button>
            </div>
            ${(data||[]).length ? (data||[]).map(d => `
            <div class="card mb-2">
                <div class="flex-between mb-1">
                    <p style="font-weight:600;">${UI.esc(d.subject||'Reclamação')}</p>
                    <span class="status status-${d.status==='resolved'?'confirmed':d.status==='rejected'?'cancelled':'pending'}">
                        ${d.status==='resolved'?'Resolvida':d.status==='rejected'?'Rejeitada':'Aberta'}
                    </span>
                </div>
                <p class="text-sm text-muted">${UI.esc((d.description||'').slice(0,80))}…</p>
                <p class="text-xs text-muted mt-1">${UI.dateStr(d.created_at)}</p>
                ${d.resolution ? `<p class="text-sm mt-2"><strong>Resolução:</strong> ${UI.esc(d.resolution)}</p>` : ''}
            </div>`).join('')
            : UI.emptyState('fas fa-gavel', 'Sem reclamações.', '', '')}`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    function _newDispute() {
        UI.modal({
            title: 'Nova Reclamação',
            body: `
                <div class="form-group">
                    <label class="form-label">Assunto *</label>
                    <input type="text" id="disputeSubject" class="form-input" placeholder="Resumo do problema">
                </div>
                <div class="form-group">
                    <label class="form-label">Descrição *</label>
                    <textarea id="disputeDesc" class="form-input" placeholder="Descreva o problema em detalhe…"></textarea>
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal()">Cancelar</button>
                <button class="btn btn-danger btn-sm" onclick="App._submitDispute()">Enviar reclamação</button>`
        });
    }

    async function _submitDispute() {
        const subject = document.getElementById('disputeSubject')?.value?.trim();
        const desc    = document.getElementById('disputeDesc')?.value?.trim();
        if (!subject || !desc) return UI.toast('Preencha todos os campos', 'warning');
        UI.showLoading('A enviar…');
        try {
            const uid = Auth.getSession().user.id;
            await window.SUPABASE_CONFIG.client.from('disputes').insert({ user_id: uid, subject, description: desc, status: 'open' });
            UI.closeModal();
            UI.toast('Reclamação enviada!', 'success');
            renderDisputes();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    // ── LOJA DO COMERCIANTE ───────────────────────────────────
    async function renderStore(merchantId) {
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const db = window.SUPABASE_CONFIG.client;
            const [{ data: m }, { data: products }] = await Promise.all([
                db.from('merchants').select('*, users(name,avatar_url,bio,location)').eq('id', merchantId).single(),
                db.from('products').select('*, product_images(*)').eq('merchant_id', merchantId).eq('status', 'active')
            ]);
            c.innerHTML = `
            <button class="btn btn-secondary btn-sm mb-3" onclick="history.back()">
                <i class="fas fa-arrow-left"></i> Voltar
            </button>
            <div class="card mb-3" style="text-align:center;padding:24px;">
                ${UI.avatarHtml(m.store_logo || m.users?.avatar_url, m.store_name, 'avatar-xl')}
                <h2 style="font-weight:700;margin-top:12px;">${UI.esc(m.store_name || 'Loja')}</h2>
                ${m.users?.location ? `<p class="text-sm text-muted"><i class="fas fa-map-marker-alt"></i> ${UI.esc(m.users.location)}</p>` : ''}
                ${m.store_description ? `<p class="text-sm mt-2">${UI.esc(m.store_description)}</p>` : ''}
                <div style="display:flex;justify-content:center;gap:20px;margin-top:12px;">
                    <div><p class="font-bold text-blue">${m.total_sales||0}</p><p class="text-xs text-muted">Vendas</p></div>
                    <div><p class="font-bold text-blue">${m.rating||'0.0'}</p><p class="text-xs text-muted">Avaliação</p></div>
                    <div><p class="font-bold text-blue">${(products||[]).length}</p><p class="text-xs text-muted">Produtos</p></div>
                </div>
                ${Auth.isLoggedIn() ? `
                <button class="btn btn-outline mt-3" style="width:auto;padding:8px 20px;" onclick="Messages.startChat('${merchantId}')">
                    <i class="fas fa-comments"></i> Enviar mensagem
                </button>` : ''}
            </div>
            <p class="section-title">Produtos da loja</p>
            ${(products||[]).length
                ? `<div class="products-grid">${(products||[]).map(p => {
                    const img = (p.product_images||[]).find(i=>i.is_primary)||(p.product_images||[])[0];
                    return `<div class="product-card card-hover" onclick="App.navigate('product?id=${p.id}')">
                        <div class="product-img">${img?`<img src="${img.image_url}" loading="lazy">`:`<div class="product-img-placeholder"><i class="fas fa-image"></i></div>`}</div>
                        <div class="product-info"><div class="product-name">${UI.esc(p.name)}</div><div class="product-price">${UI.currency(p.price)}</div></div>
                    </div>`;}).join('')}</div>`
                : UI.emptyState('fas fa-box-open', 'Esta loja ainda não tem produtos.', '', '')}`;
        } catch(e) { c.innerHTML = UI.errorPage('Loja não encontrada'); }
    }

    // ── SOBRE ─────────────────────────────────────────────────
    function renderAbout() {
        document.getElementById('mainContent').innerHTML = `
        <div style="max-width:500px;margin:0 auto;">

            <!-- CABEÇALHO APP -->
            <div class="card text-center mb-3" style="padding:28px 20px;">
                <img src="img/logo.png" onerror="this.outerHTML='<div style=\'width:72px;height:72px;background:var(--blue);border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:2rem;color:white;font-weight:700;\'>A</div>'"
                    style="width:72px;height:72px;border-radius:16px;object-fit:cover;margin:0 auto 12px;display:block;">
                <h2 style="font-weight:700;font-size:1.2rem;">Mercado Digital AID</h2>
                <p class="text-muted text-sm mt-1">Plataforma de comércio digital em Moçambique</p>
                <span style="display:inline-block;margin-top:8px;background:var(--blue-light);color:var(--blue);padding:3px 12px;border-radius:20px;font-size:.72rem;font-weight:600;">Versão 1.0 — AID Group</span>
            </div>

            <!-- RESUMO DA APP -->
            <div class="card mb-3">
                <p class="section-title">O que é o Mercado AID?</p>
                <p class="text-sm" style="line-height:1.8;">
                    O <strong>Mercado Digital AID</strong> é uma plataforma de comércio electrónico criada especialmente para Moçambique. Permite a qualquer pessoa comprar e vender produtos e serviços de forma simples, segura e conveniente directamente pelo telemóvel.
                </p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px;">
                    <div style="background:var(--blue-light);border-radius:10px;padding:12px;text-align:center;">
                        <i class="fas fa-store" style="font-size:1.4rem;color:var(--blue);"></i>
                        <p style="font-size:.75rem;font-weight:600;margin-top:6px;">Compre e venda</p>
                    </div>
                    <div style="background:var(--green-light);border-radius:10px;padding:12px;text-align:center;">
                        <i class="fas fa-receipt" style="font-size:1.4rem;color:var(--green);"></i>
                        <p style="font-size:.75rem;font-weight:600;margin-top:6px;">Pagamentos seguros</p>
                    </div>
                    <div style="background:var(--orange-light);border-radius:10px;padding:12px;text-align:center;">
                        <i class="fas fa-comments" style="font-size:1.4rem;color:var(--orange);"></i>
                        <p style="font-size:.75rem;font-weight:600;margin-top:6px;">Chat com tradutor</p>
                    </div>
                    <div style="background:var(--blue-light);border-radius:10px;padding:12px;text-align:center;">
                        <i class="fas fa-truck" style="font-size:1.4rem;color:var(--blue);"></i>
                        <p style="font-size:.75rem;font-weight:600;margin-top:6px;">Rastreio de pedidos</p>
                    </div>
                </div>
            </div>

            <!-- VERSÃO -->
            <div class="card mb-3" style="background:var(--gray-50);">
                <div style="display:flex;align-items:center;gap:12px;">
                    <div style="width:40px;height:40px;background:var(--blue);border-radius:10px;display:flex;align-items:center;justify-content:center;color:white;flex-shrink:0;">
                        <i class="fas fa-code-branch"></i>
                    </div>
                    <div>
                        <p style="font-weight:700;">Versão 1.0</p>
                        <p class="text-xs text-muted">Primeira versão pública da plataforma</p>
                    </div>
                </div>
                <div style="margin-top:12px;padding:10px;background:var(--green-light);border-radius:8px;border-left:3px solid var(--green);">
                    <p style="font-size:.78rem;color:var(--green);font-weight:600;"><i class="fas fa-star"></i> Estreia oficial — nunca usada publicamente antes.</p>
                    <p style="font-size:.75rem;color:#555;margin-top:4px;">Esta é a primeira versão oficial do Mercado Digital AID, lançada com todas as funcionalidades essenciais para o comércio digital em Moçambique.</p>
                </div>
            </div>

            <!-- DESENVOLVEDOR -->
            <div class="card mb-3" style="background:linear-gradient(135deg,#009a44 0%,#009a44 33%,#ffcc00 33%,#ffcc00 66%,#dc143c 66%,#dc143c 100%);padding:3px;border-radius:14px;">
                <div style="background:white;border-radius:12px;padding:20px;">
                    <p class="section-title">Desenvolvedor</p>
                    <div style="display:flex;gap:14px;align-items:center;">
                        <div style="width:56px;height:56px;border-radius:50%;background:var(--blue);display:flex;align-items:center;justify-content:center;color:white;font-size:1.4rem;font-weight:700;flex-shrink:0;">A</div>
                        <div>
                            <p style="font-weight:700;font-size:1rem;">Abel Isaias Domingos</p>
                            <div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
                                <span style="font-size:1.2rem;">🇲🇿</span>
                                <span class="text-sm text-muted">Moçambique</span>
                            </div>
                            <p class="text-xs text-muted mt-1">Fundador & Desenvolvedor Principal</p>
                        </div>
                    </div>
                    <p class="text-sm mt-3" style="line-height:1.7;color:#444;">
                        Aplicação desenvolvida com dedicação para digitalizar o comércio em Moçambique e empoderar empreendedores locais através da tecnologia.
                    </p>
                    <a href="mailto:abelisaiasdomingos@gmail.com"
                        style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--blue-light);border-radius:10px;text-decoration:none;color:var(--blue);margin-top:12px;">
                        <i class="fas fa-envelope"></i>
                        <span style="font-size:.85rem;font-weight:600;">abelisaiasdomingos@gmail.com</span>
                    </a>
                </div>
            </div>

            <!-- AID GROUP -->
            <div class="card mb-3">
                <p class="section-title">AID Group</p>
                <p class="text-sm" style="line-height:1.7;">A <strong>AID Group</strong> é a organização responsável pela gestão, operação e desenvolvimento contínuo da plataforma Mercado Digital AID em Moçambique.</p>
                <p class="text-sm mt-2"><i class="fas fa-envelope text-blue"></i>&nbsp; suporte@aidgroup.co.mz</p>
                <p class="text-sm mt-1"><i class="fas fa-map-marker-alt text-blue"></i>&nbsp; Maputo, Moçambique</p>
            </div>

            <!-- PARTILHAR APP -->
            <div class="card">
                <p class="section-title">Partilhar a App</p>
                <p class="text-sm text-muted mb-3">Convide os seus amigos a usar o Mercado Digital AID</p>
                <div style="display:flex;gap:12px;justify-content:center;">
                    <a href="https://wa.me/?text=Descobre%20o%20Mercado%20Digital%20AID%20%F0%9F%87%B2%F0%9F%87%BF%20A%20plataforma%20de%20com%C3%A9rcio%20digital%20de%20Mo%C3%A7ambique!" target="_blank"
                        style="width:48px;height:48px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.3rem;">
                        <i class="fab fa-whatsapp"></i></a>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=https://mercadoaid.co.mz" target="_blank"
                        style="width:48px;height:48px;border-radius:50%;background:#1877F2;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.3rem;">
                        <i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/intent/tweet?text=Descobre%20o%20Mercado%20Digital%20AID%20%F0%9F%87%B2%F0%9F%87%BF&url=https://mercadoaid.co.mz" target="_blank"
                        style="width:48px;height:48px;border-radius:50%;background:#1DA1F2;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.3rem;">
                        <i class="fab fa-twitter"></i></a>
                    <a href="https://t.me/share/url?url=https://mercadoaid.co.mz&text=Mercado%20Digital%20AID%20%F0%9F%87%B2%F0%9F%87%BF" target="_blank"
                        style="width:48px;height:48px;border-radius:50%;background:#0088cc;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.3rem;">
                        <i class="fab fa-telegram-plane"></i></a>
                    <a href="https://www.tiktok.com" target="_blank"
                        style="width:48px;height:48px;border-radius:50%;background:#010101;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.3rem;">
                        <i class="fab fa-tiktok"></i></a>
                </div>
            </div>
        </div>`;
    }


    // ── CONFIGURAÇÕES ─────────────────────────────────────────
    function renderSettings() {
        document.getElementById('mainContent').innerHTML = `
        <div style="max-width:500px;margin:0 auto;">
            <h2 class="page-title">Configurações</h2>
            <div class="card mb-3">
                <p class="section-title">Idioma</p>
                <select class="form-input" id="settingsLang" onchange="App._changeLang(this.value)">
                    <option value="pt" selected>Português (Moçambique)</option>
                    <option value="en">English</option>
                    <option value="es">Español</option>
                </select>
            </div>
            <div class="card mb-3">
                <p class="section-title">Notificações</p>
                <div class="flex-between">
                    <span class="text-sm">Notificações de pedidos</span>
                    <input type="checkbox" checked style="width:auto;">
                </div>
                <div class="flex-between mt-3">
                    <span class="text-sm">Notificações de mensagens</span>
                    <input type="checkbox" checked style="width:auto;">
                </div>
            </div>
            <div class="card mb-3">
                <p class="section-title">Conta</p>
                <button class="btn btn-outline mb-2" onclick="App.navigate('profile')">
                    <i class="fas fa-user-edit"></i> Editar perfil
                </button>
                <button class="btn btn-danger" onclick="Auth.logout()">
                    <i class="fas fa-sign-out-alt"></i> Terminar sessão
                </button>
            </div>
        </div>`;
    }

    function _changeLang(lang) {
        UI.toast('Idioma actualizado para: ' + lang, 'success');
    }

    // ── INICIALIZAÇÃO ─────────────────────────────────────────
    async function init() {
        _startClock();
        _initDrawer();
        _initBottomNav();

        // Módulos
        try { await Auth.init(); }          catch(e) { console.warn('[Auth]', e?.message); }
        try { await Cart.load(); }          catch(e) { console.warn('[Cart]', e?.message); }
        try { await Notifications.init(); } catch(e) { console.warn('[Notif]', e?.message); }

        // Rota inicial
        const hash = window.location.hash.replace('#', '') || 'home';
        await _renderPage(hash);

        // Navegação pelo hash
        window.addEventListener('hashchange', () => {
            const route = window.location.hash.replace('#', '') || 'home';
            _renderPage(route);
        });
    }

    return { init, navigate, _signContract, _newDispute, _submitDispute, _changeLang };
})();

window.App = App;

// Iniciar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => App.init());
