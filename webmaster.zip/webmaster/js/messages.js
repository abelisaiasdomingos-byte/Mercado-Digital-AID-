// ================================================================
// messages.js — Chat com tradutor integrado
// ================================================================
const Messages = (() => {
    const db  = () => window.SUPABASE_CONFIG.client;
    let _sub  = null;
    let _convId = null;

    // ── LISTAR CONVERSAS ───────────────────────────────────────
    async function render() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data: msgs } = await db().from('messages')
                .select('*, sender:sender_id(id,name,avatar_url), receiver:receiver_id(id,name,avatar_url)')
                .or(`sender_id.eq.${uid},receiver_id.eq.${uid}`)
                .order('created_at', { ascending: false });

            // Agrupar por conversa
            const convMap = {};
            (msgs || []).forEach(m => {
                if (!convMap[m.conversation_id]) convMap[m.conversation_id] = m;
            });
            const convs = Object.values(convMap);

            c.innerHTML = `
            <h2 class="page-title">Mensagens</h2>
            ${convs.length ? convs.map(m => {
                const other = m.sender_id === uid ? m.receiver : m.sender;
                return `
                <div class="card card-hover mb-2" onclick="Messages.renderChat('${m.conversation_id}','${other?.id}')">
                    <div style="display:flex;gap:12px;align-items:center;">
                        ${UI.avatarHtml(other?.avatar_url, other?.name, 'avatar-md')}
                        <div style="flex:1;min-width:0;">
                            <div class="flex-between">
                                <p style="font-weight:600;">${UI.esc(other?.name || 'Utilizador')}</p>
                                <p class="text-xs text-muted">${UI.timeAgo(m.created_at)}</p>
                            </div>
                            <p class="text-sm text-muted" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                ${m.image_url ? '📷 Imagem' : UI.esc(m.message || '')}
                            </p>
                        </div>
                    </div>
                </div>`;
            }).join('')
            : UI.emptyState('fas fa-comments', 'Sem conversas ainda.', '', '')}`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    // ── CHAT INDIVIDUAL ────────────────────────────────────────
    async function renderChat(conversationId, otherUserId) {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        _convId = conversationId || [Auth.getSession().user.id, otherUserId].sort().join('_');
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:40vh;"><div class="spinner"></div></div>`;
        try {
            const { data: other } = await db().from('users').select('name,avatar_url').eq('id', otherUserId).single();
            const { data: msgs  } = await db().from('messages')
                .select('*, sender:sender_id(name,avatar_url)')
                .eq('conversation_id', _convId)
                .order('created_at', { ascending: true });

            const uid = Auth.getSession().user.id;

            c.innerHTML = `
            <div style="display:flex;flex-direction:column;height:calc(100vh - var(--header-h) - var(--nav-h) - 32px);">
                <div style="display:flex;align-items:center;gap:10px;padding-bottom:12px;border-bottom:1px solid var(--gray-200);margin-bottom:12px;">
                    <button class="btn btn-secondary btn-sm btn-icon" onclick="Messages.render()">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    ${UI.avatarHtml(other?.avatar_url, other?.name, 'avatar-sm')}
                    <div>
                        <p style="font-weight:600;">${UI.esc(other?.name || 'Utilizador')}</p>
                        <p class="text-xs text-muted">Online</p>
                    </div>
                    <button class="btn btn-secondary btn-sm" style="margin-left:auto;width:auto;" onclick="Messages._toggleTranslator()">
                        <i class="fas fa-language"></i> Traduzir
                    </button>
                </div>

                <div id="chatMessages" style="flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:8px;padding-bottom:8px;">
                    ${(msgs||[]).map(m => msgBubble(m, uid)).join('')}
                </div>

                <div id="translatorBar" style="display:none;background:var(--blue-light);border-radius:var(--radius);padding:10px;margin-bottom:8px;">
                    <p class="text-xs text-blue font-bold mb-2"><i class="fas fa-language"></i> Tradutor automático</p>
                    <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:center;">
                        <select id="langFrom" class="form-input" style="padding:6px;font-size:.78rem;">
                            <option value="pt">Português</option>
                            <option value="en">Inglês</option>
                            <option value="es">Espanhol</option>
                            <option value="fr">Francês</option>
                            <option value="zh">Chinês</option>
                            <option value="ar">Árabe</option>
                        </select>
                        <i class="fas fa-arrow-right text-blue"></i>
                        <select id="langTo" class="form-input" style="padding:6px;font-size:.78rem;">
                            <option value="en">Inglês</option>
                            <option value="pt">Português</option>
                            <option value="es">Espanhol</option>
                            <option value="fr">Francês</option>
                            <option value="zh">Chinês</option>
                            <option value="ar">Árabe</option>
                        </select>
                    </div>
                </div>

                <div style="display:flex;gap:8px;align-items:flex-end;">
                    <button class="btn btn-secondary btn-sm btn-icon" onclick="Messages._sendImage('${otherUserId}')">
                        <i class="fas fa-image"></i>
                    </button>
                    <textarea id="chatInput" class="form-input" style="flex:1;resize:none;min-height:44px;max-height:100px;padding:10px;"
                        placeholder="Escreva uma mensagem…" rows="1"
                        onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();Messages.sendMessage('${otherUserId}');}"></textarea>
                    <button class="btn btn-primary btn-sm btn-icon" onclick="Messages.sendMessage('${otherUserId}')">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>`;

            // Scroll para o fundo
            const chatEl = document.getElementById('chatMessages');
            if (chatEl) chatEl.scrollTop = chatEl.scrollHeight;

            // Marcar como lidas
            await db().from('messages').update({ is_read: true }).eq('conversation_id', _convId).eq('receiver_id', uid);

            // Subscrever novas mensagens
            if (_sub) _sub.unsubscribe();
            _sub = db().channel('chat_' + _convId)
                .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${_convId}` },
                    async payload => {
                        const { data: newMsg } = await db().from('messages').select('*, sender:sender_id(name,avatar_url)').eq('id', payload.new.id).single();
                        const el = document.getElementById('chatMessages');
                        if (el && newMsg) {
                            el.insertAdjacentHTML('beforeend', msgBubble(newMsg, uid));
                            el.scrollTop = el.scrollHeight;
                        }
                    })
                .subscribe();
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    function msgBubble(m, uid) {
        const isMine = m.sender_id === uid;
        return `
        <div style="display:flex;flex-direction:column;align-items:${isMine ? 'flex-end' : 'flex-start'};">
            <div style="max-width:75%;background:${isMine ? 'var(--blue)' : 'var(--white)'};color:${isMine ? 'white' : 'var(--gray-900)'};padding:10px 14px;border-radius:${isMine ? '16px 16px 4px 16px' : '16px 16px 16px 4px'};box-shadow:var(--shadow);">
                ${m.image_url ? `<img src="${m.image_url}" style="width:100%;max-width:200px;border-radius:8px;margin-bottom:4px;cursor:pointer;" onclick="UI.modal({title:'Imagem',body:'<img src=\'${m.image_url}\' style=\'width:100%;border-radius:8px;\'>'})" >` : ''}
                ${m.message ? `<p style="font-size:.88rem;word-break:break-word;">${UI.esc(m.message)}</p>` : ''}
                ${m.translated ? `<p style="font-size:.75rem;opacity:.75;margin-top:4px;font-style:italic;">${UI.esc(m.translated)}</p>` : ''}
            </div>
            <p style="font-size:.65rem;color:var(--gray-400);margin-top:2px;">${UI.timeAgo(m.created_at)}</p>
        </div>`;
    }

    async function sendMessage(otherUserId) {
        const input = document.getElementById('chatInput');
        const text  = input?.value?.trim();
        if (!text) return;
        input.value = '';
        const uid     = Auth.getSession().user.id;
        const langFrom = document.getElementById('langFrom')?.value;
        const langTo   = document.getElementById('langTo')?.value;

        let translated = null;
        if (document.getElementById('translatorBar')?.style.display !== 'none' && langFrom !== langTo) {
            translated = await _translate(text, langFrom, langTo);
        }

        try {
            await db().from('messages').insert({
                conversation_id: _convId, sender_id: uid, receiver_id: otherUserId,
                message: text, translated, original_lang: langFrom
            });
        } catch(e) { UI.toast('Erro ao enviar mensagem', 'error'); }
    }

    async function _sendImage(otherUserId) {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = 'image/*';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            UI.showLoading('A enviar imagem…');
            try {
                const uid  = Auth.getSession().user.id;
                const path = `chat/${uid}/${Date.now()}.${file.name.split('.').pop()}`;
                const { error: upErr } = await db().storage.from('chat-images').upload(path, file);
                if (upErr) throw upErr;
                const { data: { publicUrl } } = db().storage.from('chat-images').getPublicUrl(path);
                await db().from('messages').insert({
                    conversation_id: _convId, sender_id: uid, receiver_id: otherUserId, image_url: publicUrl
                });
            } catch(e) { UI.toast('Erro ao enviar imagem', 'error'); }
            finally { UI.hideLoading(); }
        };
        input.click();
    }

    function _toggleTranslator() {
        const bar = document.getElementById('translatorBar');
        if (bar) bar.style.display = bar.style.display === 'none' ? '' : 'none';
    }

    async function _translate(text, from, to) {
        try {
            const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${from}|${to}`);
            const json = await res.json();
            return json.responseData?.translatedText || null;
        } catch(e) { return null; }
    }

    function startChat(otherUserId) {
        const uid  = Auth.getSession()?.user?.id;
        if (!uid)  return Auth.renderLogin();
        const convId = [uid, otherUserId].sort().join('_');
        renderChat(convId, otherUserId);
    }

    return { render, renderChat, sendMessage, _sendImage, _toggleTranslator, startChat };
})();

window.Messages = Messages;
