// ================================================================
// notifications.js — Notificações em tempo real
// ================================================================
const Notifications = (() => {
    const db = () => window.SUPABASE_CONFIG.client;
    let _sub = null;

    async function init() {
        if (!Auth.isLoggedIn()) return;
        try {
            await _updateBadge();
            const uid = Auth.getSession().user.id;
            _sub = db().channel('notif_' + uid)
                .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${uid}` },
                    payload => { _updateBadge(); UI.toast(payload.new.title, 'info'); })
                .subscribe();
        } catch(e) { console.warn('[Notifications.init]', e?.message); }
    }

    async function _updateBadge() {
        try {
            const uid = Auth.getSession()?.user?.id;
            if (!uid) return;
            const { count } = await db().from('notifications').select('*', { count: 'exact', head: true }).eq('user_id', uid).eq('is_read', false);
            const badge = document.getElementById('notifBadge');
            if (badge) { badge.textContent = count || 0; badge.classList.toggle('show', (count || 0) > 0); }
        } catch(e) {}
    }

    async function render() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data: notifs } = await db().from('notifications').select('*').eq('user_id', uid).order('created_at', { ascending: false });
            await db().from('notifications').update({ is_read: true }).eq('user_id', uid).eq('is_read', false);
            await _updateBadge();

            const iconMap = { order: 'fa-box', payment: 'fa-receipt', message: 'fa-comments', wallet: 'fa-wallet', system: 'fa-bell', review: 'fa-star' };

            c.innerHTML = `
            <div class="flex-between mb-4">
                <h2 class="page-title" style="margin:0;">Notificações</h2>
                ${(notifs||[]).length ? `<button class="btn btn-secondary btn-sm" onclick="Notifications.clearAll()">Limpar tudo</button>` : ''}
            </div>
            ${(notifs||[]).length ? (notifs||[]).map(n => `
            <div class="card card-hover mb-2" style="${!n.is_read ? 'border-left:3px solid var(--blue);' : ''}">
                <div style="display:flex;gap:12px;align-items:flex-start;">
                    <div style="width:40px;height:40px;border-radius:50%;background:var(--blue-light);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--blue);">
                        <i class="fas ${iconMap[n.type] || 'fa-bell'}"></i>
                    </div>
                    <div style="flex:1;">
                        <p style="font-weight:600;font-size:.88rem;">${UI.esc(n.title)}</p>
                        ${n.message ? `<p class="text-sm text-muted mt-1">${UI.esc(n.message)}</p>` : ''}
                        <p class="text-xs text-muted mt-1">${UI.timeAgo(n.created_at)}</p>
                    </div>
                </div>
            </div>`).join('')
            : UI.emptyState('fas fa-bell', 'Não tem notificações.', '', '')}`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    async function clearAll() {
        UI.confirm('Apagar todas as notificações?', async () => {
            try {
                const uid = Auth.getSession().user.id;
                await db().from('notifications').delete().eq('user_id', uid);
                render();
            } catch(e) { UI.toast('Erro ao limpar', 'error'); }
        });
    }

    async function send(userId, title, message, type = 'system', referenceId = null) {
        try {
            await db().from('notifications').insert({ user_id: userId, title, message, type, reference_id: referenceId });
        } catch(e) {}
    }

    function destroy() { if (_sub) { _sub.unsubscribe(); _sub = null; } }

    return { init, render, clearAll, send, destroy };
})();

window.Notifications = Notifications;
