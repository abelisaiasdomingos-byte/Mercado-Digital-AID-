// ================================================================
// orders.js — Pedidos (cliente e comerciante)
// ================================================================
const Orders = (() => {
    const db = () => window.SUPABASE_CONFIG.client;

    const STATUS_LABEL = {
        pending        : 'Pendente',
        payment_sent   : 'Pagamento enviado',
        confirmed      : 'Confirmado',
        preparing      : 'Em preparação',
        shipped        : 'Enviado',
        in_transit     : 'Em trânsito',
        near_delivery  : 'Perto de si',
        delivered      : 'Entregue',
        completed      : 'Concluído',
        cancelled      : 'Cancelado'
    };

    const STATUS_CSS = {
        pending        : 'pending',
        payment_sent   : 'pending',
        confirmed      : 'confirmed',
        preparing      : 'pending',
        shipped        : 'confirmed',
        in_transit     : 'confirmed',
        near_delivery  : 'confirmed',
        delivered      : 'confirmed',
        completed      : 'confirmed',
        cancelled      : 'cancelled'
    };

    // ── LISTAR PEDIDOS ─────────────────────────────────────────
    async function render() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid       = Auth.getSession().user.id;
            const isMerch   = Auth.isMerchant();

            let q = db().from('orders')
                .select('*, order_items(product_name, quantity, unit_price)')
                .order('created_at', { ascending: false });

            if (isMerch) {
                q = db().from('orders')
                    .select('*, order_items(product_name, quantity, unit_price), buyer:user_id(name, avatar_url)')
                    .or(`user_id.eq.${uid},merchant_id.eq.${uid}`)
                    .order('created_at', { ascending: false });
            } else {
                q = q.eq('user_id', uid);
            }

            const { data: orders } = await q;

            c.innerHTML = `
            <div class="tabs">
                <button class="tab-btn active" onclick="Orders._filterStatus('all',this)">Todos</button>
                <button class="tab-btn" onclick="Orders._filterStatus('pending',this)">Pendentes</button>
                <button class="tab-btn" onclick="Orders._filterStatus('confirmed',this)">Activos</button>
                <button class="tab-btn" onclick="Orders._filterStatus('completed',this)">Concluídos</button>
            </div>
            <div id="ordersList">
                ${(orders||[]).length
                    ? (orders||[]).map(o => orderCardHtml(o, uid)).join('')
                    : UI.emptyState('fas fa-box', 'Sem pedidos ainda.', 'Ir ao mercado', "App.navigate('market')")}
            </div>`;

            window._allOrders = orders || [];
            window._ordersUid = uid;
        } catch(e) { c.innerHTML = UI.errorPage('Erro ao carregar pedidos'); }
    }

    function orderCardHtml(o, uid) {
        const isMine = o.user_id === uid;
        const items  = o.order_items || [];
        const first  = items[0];
        return `
        <div class="card card-hover mb-2" data-status="${o.status}" onclick="Orders.renderDetail('${o.id}')">
            <div class="flex-between mb-2">
                <div>
                    <p style="font-weight:700;font-size:.82rem;color:var(--blue);">${UI.esc(o.order_number || o.id.slice(0,8).toUpperCase())}</p>
                    <p class="text-xs text-muted">${UI.dateStr(o.created_at)}</p>
                </div>
                <span class="status status-${STATUS_CSS[o.status] || 'pending'}">${STATUS_LABEL[o.status] || o.status}</span>
            </div>
            ${first ? `<p class="text-sm" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${UI.esc(first.product_name)}${items.length > 1 ? ` +${items.length-1} item(s)` : ''}</p>` : ''}
            <div class="flex-between mt-2">
                ${o.buyer ? `<span class="text-xs text-muted"><i class="fas fa-user"></i> ${UI.esc(o.buyer.name)}</span>` : '<span></span>'}
                <span class="font-bold text-blue">${UI.currency(o.total_amount)}</span>
            </div>
        </div>`;
    }

    function _filterStatus(status, btn) {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const list   = document.getElementById('ordersList');
        const uid    = window._ordersUid;
        let filtered = window._allOrders || [];
        if (status !== 'all') {
            if (status === 'pending')   filtered = filtered.filter(o => ['pending','payment_sent','preparing'].includes(o.status));
            if (status === 'confirmed') filtered = filtered.filter(o => ['confirmed','shipped','in_transit','near_delivery','delivered'].includes(o.status));
            if (status === 'completed') filtered = filtered.filter(o => ['completed','cancelled'].includes(o.status));
        }
        list.innerHTML = filtered.length
            ? filtered.map(o => orderCardHtml(o, uid)).join('')
            : UI.emptyState('fas fa-box', 'Sem pedidos nesta categoria.', '', '');
    }

    // ── DETALHE DO PEDIDO ──────────────────────────────────────
    async function renderDetail(orderId) {
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data: o } = await db().from('orders')
                .select('*, order_items(*), buyer:user_id(name,phone,avatar_url), merchant:merchant_id(store_name,users(name,phone))')
                .eq('id', orderId).single();

            const isMerchant = Auth.isMerchant() && o.merchant_id === uid;
            const items      = o.order_items || [];

            const STEPS = ['pending','payment_sent','confirmed','preparing','shipped','in_transit','near_delivery','delivered','completed'];
            const curIdx = STEPS.indexOf(o.status);

            c.innerHTML = `
            <button class="btn btn-secondary btn-sm mb-3" onclick="Orders.render()">
                <i class="fas fa-arrow-left"></i> Voltar
            </button>

            <div class="card mb-3">
                <div class="flex-between mb-2">
                    <p style="font-weight:700;color:var(--blue);">${UI.esc(o.order_number || o.id.slice(0,8).toUpperCase())}</p>
                    <span class="status status-${STATUS_CSS[o.status]||'pending'}">${STATUS_LABEL[o.status]||o.status}</span>
                </div>
                <p class="text-xs text-muted">${UI.dateStr(o.created_at)}</p>
            </div>

            <!-- RASTREIO -->
            <div class="card mb-3">
                <p class="section-title">Rastreio do Pedido</p>
                <div style="position:relative;padding-left:20px;">
                    ${STEPS.filter(s => s !== 'cancelled').map((step, i) => {
                        const done    = i <= curIdx;
                        const current = i === curIdx;
                        return `
                        <div style="display:flex;align-items:center;gap:12px;padding:8px 0;position:relative;">
                            <div style="position:absolute;left:-20px;width:14px;height:14px;border-radius:50%;background:${done ? 'var(--blue)' : 'var(--gray-200)'};border:2px solid ${done ? 'var(--blue)' : 'var(--gray-200)'};flex-shrink:0;z-index:1;${current ? 'box-shadow:0 0 0 4px var(--blue-light);' : ''}"></div>
                            ${i < STEPS.filter(s=>s!=='cancelled').length - 1 ? `<div style="position:absolute;left:-14px;top:22px;width:2px;height:100%;background:${done ? 'var(--blue)' : 'var(--gray-200)'};"></div>` : ''}
                            <p style="font-size:.82rem;font-weight:${current ? '700' : '400'};color:${done ? 'var(--gray-900)' : 'var(--gray-400)'};">${STATUS_LABEL[step]||step}</p>
                        </div>`;
                    }).join('')}
                </div>
            </div>

            <!-- ITENS -->
            <div class="card mb-3">
                <p class="section-title">Itens do Pedido</p>
                ${items.map(item => `
                <div class="flex-between mb-2" style="padding-bottom:8px;border-bottom:1px solid var(--gray-100);">
                    <div>
                        <p style="font-weight:500;font-size:.88rem;">${UI.esc(item.product_name)}</p>
                        <p class="text-xs text-muted">Qtd: ${item.quantity} × ${UI.currency(item.unit_price)}</p>
                    </div>
                    <p class="font-bold">${UI.currency(item.quantity * item.unit_price)}</p>
                </div>`).join('')}
                <div class="flex-between mt-2">
                    <span class="font-bold">Total</span>
                    <span class="font-bold text-blue" style="font-size:1.1rem;">${UI.currency(o.total_amount)}</span>
                </div>
                ${o.platform_fee ? `
                <div class="flex-between mt-1">
                    <span class="text-sm text-muted">Taxa AID Group</span>
                    <span class="text-sm text-red">${UI.currency(o.platform_fee)}</span>
                </div>` : ''}
            </div>

            <!-- ENTREGA -->
            <div class="card mb-3">
                <p class="section-title">Detalhes de Entrega</p>
                <p class="text-sm"><i class="fas fa-map-marker-alt text-blue"></i> ${UI.esc(o.shipping_address)}</p>
                ${o.payment_method ? `<p class="text-sm mt-2"><i class="fas fa-mobile-alt text-blue"></i> ${UI.esc(o.payment_method)}</p>` : ''}
                ${o.tracking_code  ? `<p class="text-sm mt-2"><i class="fas fa-barcode text-blue"></i> ${UI.esc(o.tracking_code)}</p>` : ''}
                ${o.notes          ? `<p class="text-sm mt-2 text-muted">${UI.esc(o.notes)}</p>` : ''}
            </div>

            <!-- ACÇÕES CLIENTE -->
            ${!isMerchant && ['pending'].includes(o.status) ? `
            <div class="card mb-3">
                <p class="section-title">Enviar Comprovante de Pagamento</p>
                <p class="text-sm text-muted mb-2">Efectuou o pagamento? Envie o comprovante para o comerciante.</p>
                <button class="btn btn-primary" onclick="Orders._sendPaymentProof('${o.id}','${o.merchant_id}')">
                    <i class="fas fa-receipt"></i> Enviar comprovante
                </button>
            </div>` : ''}

            ${!isMerchant && o.status === 'delivered' ? `
            <button class="btn btn-success mb-2" onclick="Orders._confirmDelivery('${o.id}')">
                <i class="fas fa-check"></i> Confirmar recepção
            </button>` : ''}

            ${!isMerchant && ['pending','payment_sent'].includes(o.status) ? `
            <button class="btn btn-danger mb-2" onclick="Orders._cancelOrder('${o.id}')">
                <i class="fas fa-times"></i> Cancelar pedido
            </button>` : ''}

            <!-- ACÇÕES COMERCIANTE -->
            ${isMerchant ? `
            <div class="card mb-3">
                <p class="section-title">Actualizar Estado</p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                    ${['confirmed','preparing','shipped','in_transit','near_delivery','delivered','completed','cancelled'].map(s => `
                    <button class="btn btn-${o.status===s ? 'primary' : 'secondary'} btn-sm" onclick="Orders._updateStatus('${o.id}','${s}')">
                        ${STATUS_LABEL[s]||s}
                    </button>`).join('')}
                </div>
            </div>` : ''}`;
        } catch(e) { c.innerHTML = UI.errorPage('Pedido não encontrado'); }
    }

    // ── ACÇÕES ─────────────────────────────────────────────────
    async function _sendPaymentProof(orderId, merchantId) {
        UI.modal({
            id: 'proofModal',
            title: 'Enviar Comprovante',
            body: `
                <p class="text-sm text-muted mb-3">Envie a foto do comprovante de pagamento ao comerciante.</p>
                <div class="form-group">
                    <label class="form-label">Foto do comprovante *</label>
                    <input type="file" id="proofFile" class="form-input" accept="image/*">
                </div>
                <div class="form-group">
                    <label class="form-label">Método usado</label>
                    <select id="proofMethod" class="form-input">
                        <option value="M-Pesa">M-Pesa</option>
                        <option value="e-Mola">e-Mola</option>
                        <option value="M-Cash">M-Cash</option>
                        <option value="Banco">Transferência Bancária</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Legenda</label>
                    <input type="text" id="proofCaption" class="form-input" placeholder="Ex: Pagamento pedido #AID-001">
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal('proofModal')">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Orders._submitProof('${orderId}','${merchantId}')">
                    <i class="fas fa-paper-plane"></i> Enviar
                </button>`
        });
    }

    async function _submitProof(orderId, merchantId) {
        const file    = document.getElementById('proofFile')?.files?.[0];
        const method  = document.getElementById('proofMethod')?.value;
        const caption = document.getElementById('proofCaption')?.value?.trim();
        if (!file) return UI.toast('Seleccione a foto do comprovante', 'warning');
        UI.showLoading('A enviar…');
        try {
            const uid  = Auth.getSession().user.id;
            const path = `receipts/${uid}/${Date.now()}.${file.name.split('.').pop()}`;
            const { error: upErr } = await db().storage.from('receipt-images').upload(path, file);
            if (upErr) throw upErr;
            const { data: { publicUrl } } = db().storage.from('receipt-images').getPublicUrl(path);

            await db().from('payment_receipts').insert({
                order_id: orderId, sender_id: uid, receiver_id: merchantId,
                image_url: publicUrl, method, caption, status: 'pending'
            });
            await db().from('orders').update({ status: 'payment_sent', payment_method: method }).eq('id', orderId);

            UI.closeModal('proofModal');
            UI.toast('Comprovante enviado ao comerciante!', 'success');
            renderDetail(orderId);
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    async function _confirmDelivery(orderId) {
        UI.confirm('Confirmar que recebeu o pedido?', async () => {
            UI.showLoading('A confirmar…');
            try {
                await db().from('orders').update({ status: 'completed' }).eq('id', orderId);
                UI.toast('Entrega confirmada! Obrigado.', 'success');
                renderDetail(orderId);
            } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
            finally { UI.hideLoading(); }
        });
    }

    async function _cancelOrder(orderId) {
        UI.confirm('Tem a certeza que quer cancelar este pedido?', async () => {
            UI.showLoading('A cancelar…');
            try {
                await db().from('orders').update({ status: 'cancelled' }).eq('id', orderId);
                UI.toast('Pedido cancelado.', 'warning');
                render();
            } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
            finally { UI.hideLoading(); }
        });
    }

    async function _updateStatus(orderId, status) {
        UI.showLoading('A actualizar…');
        try {
            await db().from('orders').update({ status }).eq('id', orderId);
            await db().from('delivery_tracking').insert({ order_id: orderId, status, description: STATUS_LABEL[status] || status, updated_by: Auth.getSession().user.id });
            UI.toast('Estado actualizado: ' + STATUS_LABEL[status], 'success');
            renderDetail(orderId);
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    return { render, renderDetail, _filterStatus, _sendPaymentProof, _submitProof, _confirmDelivery, _cancelOrder, _updateStatus };
})();

window.Orders = Orders;
