// ================================================================
// products.js — Produtos (listagem, detalhe, adicionar, editar)
// ================================================================
const Products = (() => {
    const db = () => window.SUPABASE_CONFIG.client;

    // ── BUSCAR PRODUTOS ────────────────────────────────────────
    async function getAll(filters = {}, page = 1, limit = 20) {
        try {
            let q = db().from('products')
                .select('*, product_images(*), merchants(store_name)', { count: 'exact' })
                .eq('status', 'active')
                .order('created_at', { ascending: false })
                .range((page - 1) * limit, page * limit - 1);
            if (filters.search)   q = q.ilike('name', `%${filters.search}%`);
            if (filters.category) q = q.eq('category_id', filters.category);
            const { data, error, count } = await q;
            if (error) throw error;
            return { products: data || [], total: count || 0 };
        } catch(e) { console.warn('[Products.getAll]', e?.message); return { products: [], total: 0 }; }
    }

    async function getCategories() {
        try {
            const { data, error } = await db().from('categories').select('*').order('name');
            if (error) throw error;
            return data || [];
        } catch(e) { return []; }
    }

    async function getMerchantProducts() {
        try {
            const uid = Auth.getSession()?.user?.id;
            const { data, error } = await db().from('products')
                .select('*, product_images(*)')
                .eq('merchant_id', uid)
                .order('created_at', { ascending: false });
            if (error) throw error;
            return data || [];
        } catch(e) { return []; }
    }

    // ── HELPERS VISUAIS ────────────────────────────────────────
    function primaryImg(product) {
        const imgs = product.product_images || [];
        const primary = imgs.find(i => i.is_primary) || imgs[0];
        return primary?.image_url || null;
    }

    function productCardHtml(p) {
        const img = primaryImg(p);
        return `
        <div class="product-card card-hover" onclick="Products.renderDetail('${p.id}')">
            <div class="product-img">
                ${img
                    ? `<img src="${img}" alt="${UI.esc(p.name)}" loading="lazy" onerror="this.parentElement.innerHTML='<div class=product-img-placeholder><i class=fas fa-image></i></div>'">`
                    : `<div class="product-img-placeholder"><i class="fas fa-image"></i></div>`}
            </div>
            <div class="product-info">
                <div class="product-name">${UI.esc(p.name)}</div>
                <div class="product-price">${UI.currency(p.price)}</div>
            </div>
        </div>`;
    }

    // ── HOME ───────────────────────────────────────────────────
    async function renderHome() {
        const c = document.getElementById('mainContent');
        const [{ products }, cats] = await Promise.all([getAll({}, 1, 6), getCategories()]);

        c.innerHTML = `
        <div class="search-bar">
            <div class="search-wrap" style="flex:1;">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" placeholder="O que procura?" id="homeSearch"
                    onkeydown="if(event.key==='Enter') App.navigate('market?search='+encodeURIComponent(this.value))">
            </div>
            <button class="btn btn-primary btn-sm" style="width:auto;border-radius:30px;"
                onclick="App.navigate('market?search='+encodeURIComponent(document.getElementById('homeSearch').value))">
                <i class="fas fa-search"></i>
            </button>
        </div>

        ${cats.length ? `
        <p class="section-title">Categorias</p>
        <div class="categories-grid mb-4">
            ${cats.slice(0,8).map(cat => `
            <div class="category-item" onclick="App.navigate('market?category=${cat.id}')">
                <div class="category-icon"><i class="${UI.esc(cat.icon)}"></i></div>
                <div class="category-label">${UI.esc(cat.name)}</div>
            </div>`).join('')}
        </div>` : ''}

        <div class="flex-between mb-3">
            <p class="section-title" style="margin:0;">Produtos em Destaque</p>
            <button class="btn btn-outline btn-sm" onclick="App.navigate('market')">Ver todos</button>
        </div>

        ${products.length
            ? `<div class="products-grid">${products.map(productCardHtml).join('')}</div>`
            : UI.emptyState('fas fa-store', 'Ainda não há produtos disponíveis.', '', '')}`;
    }

    // ── MERCADO ────────────────────────────────────────────────
    async function renderMarket() {
        const c = document.getElementById('mainContent');
        const params   = new URLSearchParams(window.location.hash.split('?')[1] || '');
        const search   = params.get('search')   || '';
        const category = params.get('category') || '';
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;

        const cats = await getCategories();
        const filters = {};
        if (search)   filters.search   = search;
        if (category) filters.category = category;
        const { products, total } = await getAll(filters);

        c.innerHTML = `
        <div class="search-bar">
            <div class="search-wrap" style="flex:1;">
                <i class="fas fa-search search-icon"></i>
                <input type="text" class="search-input" id="marketSearch" value="${UI.esc(search)}" placeholder="Pesquisar…"
                    onkeydown="if(event.key==='Enter') App.navigate('market?search='+encodeURIComponent(this.value))">
            </div>
        </div>

        ${cats.length ? `
        <div style="display:flex;gap:8px;overflow-x:auto;padding-bottom:8px;margin-bottom:12px;">
            <button class="btn btn-${!category ? 'primary' : 'secondary'} btn-sm" style="white-space:nowrap;"
                onclick="App.navigate('market')">Todos</button>
            ${cats.map(cat => `
            <button class="btn btn-${category == cat.id ? 'primary' : 'secondary'} btn-sm" style="white-space:nowrap;"
                onclick="App.navigate('market?category=${cat.id}')">
                <i class="${UI.esc(cat.icon)}"></i> ${UI.esc(cat.name)}
            </button>`).join('')}
        </div>` : ''}

        <p class="text-sm text-muted mb-3">${total} produto${total !== 1 ? 's' : ''} encontrado${total !== 1 ? 's' : ''}</p>

        ${products.length
            ? `<div class="products-grid">${products.map(productCardHtml).join('')}</div>`
            : UI.emptyState('fas fa-search', 'Nenhum produto encontrado.', 'Limpar filtros', "App.navigate('market')")}`;
    }

    // ── DETALHE DO PRODUTO ─────────────────────────────────────
    async function renderDetail(productId) {
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:40vh;"><div class="spinner"></div></div>`;
        try {
            const { data: p, error } = await db().from('products')
                .select('*, product_images(*), merchants(id, store_name, store_logo, rating, created_at)')
                .eq('id', productId).single();
            if (error) throw error;
            const imgs = p.product_images || [];
            const mainImg = primaryImg(p) || '';

            c.innerHTML = `
            <button class="btn btn-secondary btn-sm mb-3" onclick="history.back()">
                <i class="fas fa-arrow-left"></i> Voltar
            </button>

            <div class="card mb-3" style="padding:0;overflow:hidden;">
                <div style="aspect-ratio:4/3;background:var(--gray-100);">
                    <img id="mainProductImg" src="${mainImg}" style="width:100%;height:100%;object-fit:cover;"
                        onerror="this.style.display='none'">
                </div>
                ${imgs.length > 1 ? `
                <div style="display:flex;gap:8px;padding:10px;overflow-x:auto;">
                    ${imgs.map(img => `
                    <img src="${img.image_url}" style="width:64px;height:64px;object-fit:cover;border-radius:8px;cursor:pointer;flex-shrink:0;"
                        onclick="document.getElementById('mainProductImg').src='${img.image_url}'">`).join('')}
                </div>` : ''}
            </div>

            <div class="card mb-3">
                <h2 style="font-weight:700;font-size:1.1rem;">${UI.esc(p.name)}</h2>
                <p class="product-price" style="font-size:1.4rem;margin:8px 0;">${UI.currency(p.price)}</p>
                ${p.condition ? `<span class="status status-active"><i class="fas fa-tag"></i> ${UI.esc(p.condition)}</span>` : ''}
                ${p.location ? `<p class="text-sm text-muted mt-2"><i class="fas fa-map-marker-alt"></i> ${UI.esc(p.location)}</p>` : ''}
                ${p.description ? `<p class="text-sm mt-3">${UI.esc(p.description)}</p>` : ''}
                <div class="divider"></div>
                <div class="flex-between">
                    <span class="text-sm text-muted">Disponível: <strong>${p.quantity}</strong> unidades</span>
                    <span class="text-sm text-muted">${UI.dateStr(p.created_at)}</span>
                </div>
            </div>

            ${p.merchants ? `
            <div class="card mb-3">
                <p class="section-title">Vendedor</p>
                <div class="flex gap-3" style="align-items:center;cursor:pointer;" onclick="App.navigate('store?id=${p.merchants.id}')">
                    ${UI.avatarHtml(p.merchants.store_logo, p.merchants.store_name, 'avatar-md')}
                    <div style="flex:1;">
                        <p style="font-weight:600;">${UI.esc(p.merchants.store_name || 'Loja')}</p>
                        <p class="text-sm text-muted"><i class="fas fa-star" style="color:#f59e0b;"></i> ${p.merchants.rating || '0.0'}</p>
                        <p class="text-xs text-muted mt-1"><i class="fas fa-clock"></i> No Mercado AID há ${UI.timeOnPlatform(p.merchants.created_at)}</p>
                    </div>
                    <i class="fas fa-chevron-right text-muted"></i>
                </div>
            </div>
            <div class="card mb-3">
                <p class="section-title">Partilhar este produto</p>
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <a href="https://wa.me/?text=${encodeURIComponent(p.name + ' — ' + UI.currency(p.price) + ' | Mercado Digital AID 🇲🇿')}" target="_blank"
                        style="width:44px;height:44px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.2rem;"><i class="fab fa-whatsapp"></i></a>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}" target="_blank"
                        style="width:44px;height:44px;border-radius:50%;background:#1877F2;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.2rem;"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/intent/tweet?text=${encodeURIComponent(p.name + ' — ' + UI.currency(p.price))}&url=${encodeURIComponent(window.location.href)}" target="_blank"
                        style="width:44px;height:44px;border-radius:50%;background:#1DA1F2;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.2rem;"><i class="fab fa-twitter"></i></a>
                    <a href="https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(p.name)}" target="_blank"
                        style="width:44px;height:44px;border-radius:50%;background:#0088cc;display:flex;align-items:center;justify-content:center;color:white;text-decoration:none;font-size:1.2rem;"><i class="fab fa-telegram-plane"></i></a>
                    <button onclick="navigator.clipboard?.writeText(window.location.href).then(()=>UI.toast('Link copiado!','success'))"
                        style="width:44px;height:44px;border-radius:50%;background:var(--gray-200);border:none;cursor:pointer;font-size:1.1rem;color:var(--gray-600);"><i class="fas fa-link"></i></button>
                </div>
            </div>` : ''}

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <button class="btn btn-outline" onclick="Cart.add('${p.id}', '${UI.esc(p.name)}', ${p.price})">
                    <i class="fas fa-cart-plus"></i> Carrinho
                </button>
                <button class="btn btn-primary" onclick="App.navigate('chat?user=${p.merchants?.id}')">
                    <i class="fas fa-comments"></i> Contactar
                </button>
            </div>`;

            // Incrementar visualizações
            db().rpc('increment_product_views', { product_id: productId }).catch(() => {});
        } catch(e) {
            c.innerHTML = UI.errorPage('Produto não encontrado');
        }
    }

    // ── OS MEUS PRODUTOS (comerciante) ─────────────────────────
    async function renderMyProducts() {
        if (!Auth.isMerchant()) return document.getElementById('mainContent').innerHTML = UI.errorPage('Acesso negado');
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        const products = await getMerchantProducts();

        c.innerHTML = `
        <div class="flex-between mb-4">
            <h2 class="page-title" style="margin:0;">Os Meus Produtos</h2>
            <button class="btn btn-primary btn-sm" onclick="Products.renderAddProduct()">
                <i class="fas fa-plus"></i> Adicionar
            </button>
        </div>
        ${products.length ? products.map(p => `
        <div class="card card-hover flex-between gap-3 mb-2">
            <div style="display:flex;gap:12px;align-items:center;flex:1;min-width:0;">
                <div style="width:56px;height:56px;border-radius:8px;overflow:hidden;flex-shrink:0;background:var(--gray-100);">
                    ${primaryImg(p) ? `<img src="${primaryImg(p)}" style="width:100%;height:100%;object-fit:cover;">` : '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--gray-400);"><i class="fas fa-image"></i></div>'}
                </div>
                <div style="min-width:0;">
                    <p style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${UI.esc(p.name)}</p>
                    <p class="text-sm text-blue font-bold">${UI.currency(p.price)}</p>
                    <span class="status status-${p.status === 'active' ? 'active' : 'inactive'} text-xs">${p.status === 'active' ? 'Activo' : 'Inactivo'}</span>
                </div>
            </div>
            <div style="display:flex;gap:8px;flex-shrink:0;">
                <button class="btn btn-secondary btn-sm btn-icon" onclick="Products.renderEditProduct('${p.id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-danger btn-sm btn-icon" onclick="Products.deleteProduct('${p.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>`).join('')
        : UI.emptyState('fas fa-box-open', 'Ainda não tem produtos.', 'Adicionar produto', "Products.renderAddProduct()")}`;
    }

    async function renderAddProduct() {
        const c = document.getElementById('mainContent');
        const cats = await getCategories();
        c.innerHTML = `
        <button class="btn btn-secondary btn-sm mb-3" onclick="Products.renderMyProducts()">
            <i class="fas fa-arrow-left"></i> Voltar
        </button>
        <h2 class="page-title">Novo Produto</h2>
        <div class="card">
            <div class="form-group">
                <label class="form-label">Nome do produto *</label>
                <input type="text" id="pName" class="form-input" placeholder="Ex: Smartphone Samsung A15">
            </div>
            <div class="form-group">
                <label class="form-label">Preço (MT) *</label>
                <input type="number" id="pPrice" class="form-input" placeholder="0.00" min="0">
            </div>
            <div class="form-group">
                <label class="form-label">Categoria</label>
                <select id="pCategory" class="form-input">
                    <option value="">Seleccionar…</option>
                    ${cats.map(c => `<option value="${c.id}">${UI.esc(c.name)}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Quantidade disponível</label>
                <input type="number" id="pQty" class="form-input" value="1" min="0">
            </div>
            <div class="form-group">
                <label class="form-label">Condição</label>
                <select id="pCondition" class="form-input">
                    <option value="new">Novo</option>
                    <option value="used">Usado</option>
                    <option value="refurbished">Recondicionado</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Localização</label>
                <input type="text" id="pLocation" class="form-input" placeholder="Ex: Maputo, Sommerschield">
            </div>
            <div class="form-group">
                <label class="form-label">Método de entrega</label>
                <input type="text" id="pDelivery" class="form-input" placeholder="Ex: Entrega ao domicílio, Levantamento">
            </div>
            <div class="form-group">
                <label class="form-label">Descrição</label>
                <textarea id="pDesc" class="form-input" placeholder="Descreva o produto…"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Fotos do produto</label>
                <input type="file" id="pImages" class="form-input" multiple accept="image/*">
                <p class="form-hint">Pode seleccionar até 5 fotos</p>
            </div>
            <button class="btn btn-primary" onclick="Products.saveProduct()">
                <i class="fas fa-save"></i> Publicar produto
            </button>
        </div>`;
    }

    async function saveProduct() {
        const name     = document.getElementById('pName')?.value?.trim();
        const price    = parseFloat(document.getElementById('pPrice')?.value);
        const category = document.getElementById('pCategory')?.value;
        const qty      = parseInt(document.getElementById('pQty')?.value) || 0;
        const condition= document.getElementById('pCondition')?.value;
        const location = document.getElementById('pLocation')?.value?.trim();
        const delivery = document.getElementById('pDelivery')?.value?.trim();
        const desc     = document.getElementById('pDesc')?.value?.trim();
        const files    = document.getElementById('pImages')?.files;

        if (!name)        return UI.toast('O nome é obrigatório', 'warning');
        if (isNaN(price)) return UI.toast('Insira um preço válido', 'warning');

        UI.showLoading('A publicar produto…');
        try {
            const uid = Auth.getSession().user.id;
            const { data: prod, error } = await db().from('products').insert({
                merchant_id: uid, name, price, description: desc,
                category_id: category || null, quantity: qty,
                condition, location, delivery_method: delivery, status: 'active'
            }).select().single();
            if (error) throw error;

            // Upload imagens
            if (files?.length) {
                for (let i = 0; i < Math.min(files.length, 5); i++) {
                    const file = files[i];
                    const path = `${uid}/${prod.id}/${Date.now()}_${i}.${file.name.split('.').pop()}`;
                    const { error: upErr } = await db().storage.from('product-images').upload(path, file);
                    if (!upErr) {
                        const { data: { publicUrl } } = db().storage.from('product-images').getPublicUrl(path);
                        await db().from('product_images').insert({ product_id: prod.id, image_url: publicUrl, is_primary: i === 0, position: i });
                    }
                }
            }

            UI.toast('Produto publicado com sucesso!', 'success');
            renderMyProducts();
        } catch(e) {
            UI.toast('Erro: ' + e.message, 'error');
        } finally { UI.hideLoading(); }
    }

    async function deleteProduct(id) {
        UI.confirm('Eliminar este produto?', async () => {
            UI.showLoading('A eliminar…');
            try {
                await db().from('products').update({ status: 'deleted' }).eq('id', id);
                UI.toast('Produto eliminado', 'success');
                renderMyProducts();
            } catch(e) {
                UI.toast('Erro: ' + e.message, 'error');
            } finally { UI.hideLoading(); }
        });
    }

    async function renderEditProduct(id) {
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const { data: p } = await db().from('products').select('*').eq('id', id).single();
            const cats = await getCategories();
            c.innerHTML = `
            <button class="btn btn-secondary btn-sm mb-3" onclick="Products.renderMyProducts()">
                <i class="fas fa-arrow-left"></i> Voltar
            </button>
            <h2 class="page-title">Editar Produto</h2>
            <div class="card">
                <div class="form-group"><label class="form-label">Nome *</label>
                    <input type="text" id="peName" class="form-input" value="${UI.esc(p.name)}"></div>
                <div class="form-group"><label class="form-label">Preço (MT) *</label>
                    <input type="number" id="pePrice" class="form-input" value="${p.price}"></div>
                <div class="form-group"><label class="form-label">Categoria</label>
                    <select id="peCategory" class="form-input">
                        <option value="">Seleccionar…</option>
                        ${cats.map(cat => `<option value="${cat.id}" ${p.category_id == cat.id ? 'selected' : ''}>${UI.esc(cat.name)}</option>`).join('')}
                    </select></div>
                <div class="form-group"><label class="form-label">Quantidade</label>
                    <input type="number" id="peQty" class="form-input" value="${p.quantity}"></div>
                <div class="form-group"><label class="form-label">Localização</label>
                    <input type="text" id="peLocation" class="form-input" value="${UI.esc(p.location||'')}"></div>
                <div class="form-group"><label class="form-label">Descrição</label>
                    <textarea id="peDesc" class="form-input">${UI.esc(p.description||'')}</textarea></div>
                <div class="form-group"><label class="form-label">Estado</label>
                    <select id="peStatus" class="form-input">
                        <option value="active"   ${p.status === 'active'   ? 'selected' : ''}>Activo</option>
                        <option value="inactive" ${p.status === 'inactive' ? 'selected' : ''}>Inactivo</option>
                    </select></div>
                <button class="btn btn-primary" onclick="Products._updateProduct('${id}')">
                    <i class="fas fa-save"></i> Guardar alterações
                </button>
            </div>`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    async function _updateProduct(id) {
        const upd = {
            name       : document.getElementById('peName')?.value?.trim(),
            price      : parseFloat(document.getElementById('pePrice')?.value),
            category_id: document.getElementById('peCategory')?.value || null,
            quantity   : parseInt(document.getElementById('peQty')?.value) || 0,
            location   : document.getElementById('peLocation')?.value?.trim(),
            description: document.getElementById('peDesc')?.value?.trim(),
            status     : document.getElementById('peStatus')?.value
        };
        if (!upd.name) return UI.toast('O nome é obrigatório', 'warning');
        UI.showLoading('A guardar…');
        try {
            const { error } = await db().from('products').update(upd).eq('id', id);
            if (error) throw error;
            UI.toast('Produto actualizado!', 'success');
            renderMyProducts();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    return { getAll, getCategories, getMerchantProducts, renderHome, renderMarket, renderDetail, renderMyProducts, renderAddProduct, saveProduct, deleteProduct, renderEditProduct, _updateProduct };
})();

window.Products = Products;
