// ================================================================
// reports.js — Relatórios (apenas comerciantes)
// ================================================================
const Reports = (() => {
    const db = () => window.SUPABASE_CONFIG.client;

    async function render() {
        if (!Auth.isMerchant()) return document.getElementById('mainContent').innerHTML = UI.errorPage('Acesso negado');
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const now = new Date();
            const startMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

            const [{ data: orders }, { data: products }, { data: allOrders }] = await Promise.all([
                db().from('orders').select('total_amount, platform_fee, created_at, status').eq('merchant_id', uid).gte('created_at', startMonth),
                db().from('products').select('id, name, views, status').eq('merchant_id', uid),
                db().from('orders').select('total_amount, created_at, status').eq('merchant_id', uid).order('created_at', { ascending: false }).limit(50)
            ]);

            const confirmed    = (orders||[]).filter(o => ['confirmed','delivered','completed'].includes(o.status));
            const totalRevenue = confirmed.reduce((s, o) => s + (o.total_amount || 0), 0);
            const totalFees    = confirmed.reduce((s, o) => s + (o.platform_fee || 0), 0);
            const totalOrders  = (orders||[]).length;
            const totalProds   = (products||[]).filter(p => p.status === 'active').length;
            const totalViews   = (products||[]).reduce((s, p) => s + (p.views || 0), 0);

            // Vendas por dia (últimos 7 dias)
            const salesByDay = {};
            for (let i = 6; i >= 0; i--) {
                const d = new Date(); d.setDate(d.getDate() - i);
                const key = d.toLocaleDateString('pt-MZ', { weekday: 'short', day: '2-digit' });
                salesByDay[key] = 0;
            }
            (allOrders||[]).forEach(o => {
                const d   = new Date(o.created_at);
                const key = d.toLocaleDateString('pt-MZ', { weekday: 'short', day: '2-digit' });
                if (salesByDay[key] !== undefined) salesByDay[key] += o.total_amount || 0;
            });
            const maxVal = Math.max(...Object.values(salesByDay), 1);

            c.innerHTML = `
            <h2 class="page-title">Relatórios</h2>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
                ${statCard('fas fa-money-bill-wave', 'Receita (mês)', UI.currency(totalRevenue), 'var(--green)')}
                ${statCard('fas fa-shopping-bag', 'Pedidos (mês)', totalOrders, 'var(--blue)')}
                ${statCard('fas fa-box-open', 'Produtos activos', totalProds, 'var(--orange)')}
                ${statCard('fas fa-eye', 'Total visualizações', totalViews, 'var(--blue-dark)')}
            </div>

            <div class="card mb-3">
                <p class="section-title">Taxa AID Group (mês)</p>
                <div class="flex-between">
                    <span class="text-muted">Total em taxas</span>
                    <span class="font-bold text-red">${UI.currency(totalFees)}</span>
                </div>
                <div class="flex-between mt-2">
                    <span class="text-muted">Receita líquida</span>
                    <span class="font-bold text-green">${UI.currency(totalRevenue - totalFees)}</span>
                </div>
            </div>

            <div class="card mb-3">
                <p class="section-title">Vendas — Últimos 7 dias</p>
                <div style="display:flex;align-items:flex-end;gap:6px;height:120px;padding-top:8px;">
                    ${Object.entries(salesByDay).map(([label, val]) => `
                    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;">
                        <div style="width:100%;background:var(--blue);border-radius:4px 4px 0 0;height:${Math.max(4, (val/maxVal)*90)}px;transition:height .3s;"></div>
                        <span style="font-size:.55rem;color:var(--gray-400);text-align:center;">${label}</span>
                    </div>`).join('')}
                </div>
            </div>

            <div class="card mb-3">
                <p class="section-title">Produtos mais vistos</p>
                ${(products||[]).sort((a,b) => (b.views||0)-(a.views||0)).slice(0,5).map((p,i) => `
                <div class="flex-between mb-2">
                    <div style="display:flex;gap:8px;align-items:center;">
                        <span style="font-weight:700;color:var(--blue);width:20px;">${i+1}</span>
                        <span style="font-size:.85rem;">${UI.esc(p.name)}</span>
                    </div>
                    <span class="text-sm text-muted">${p.views||0} views</span>
                </div>`).join('') || '<p class="text-muted text-sm">Sem dados</p>'}
            </div>

            <div class="card">
                <p class="section-title">Últimos Pedidos</p>
                ${(allOrders||[]).slice(0,10).map(o => `
                <div class="flex-between mb-2" style="padding-bottom:8px;border-bottom:1px solid var(--gray-100);">
                    <div>
                        <p style="font-size:.82rem;font-weight:500;">${UI.dateStr(o.created_at)}</p>
                        <span class="status status-${o.status === 'completed' || o.status === 'delivered' ? 'confirmed' : o.status === 'cancelled' ? 'cancelled' : 'pending'}">
                            ${statusLabel(o.status)}
                        </span>
                    </div>
                    <span class="font-bold">${UI.currency(o.total_amount)}</span>
                </div>`).join('') || '<p class="text-muted text-sm">Sem pedidos</p>'}
            </div>`;
        } catch(e) { c.innerHTML = UI.errorPage('Erro ao carregar relatórios'); }
    }

    function statCard(icon, label, value, color) {
        return `
        <div class="card" style="text-align:center;padding:14px;">
            <i class="${icon}" style="font-size:1.4rem;color:${color};margin-bottom:6px;display:block;"></i>
            <p class="text-xs text-muted">${label}</p>
            <p style="font-weight:700;font-size:1rem;margin-top:4px;color:${color};">${value}</p>
        </div>`;
    }

    function statusLabel(s) {
        const m = { pending:'Pendente', confirmed:'Confirmado', shipped:'Enviado', delivered:'Entregue', completed:'Concluído', cancelled:'Cancelado' };
        return m[s] || s;
    }

    return { render };
})();

window.Reports = Reports;
