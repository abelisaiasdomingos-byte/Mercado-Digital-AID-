// ================================================================
// storage.js — Persistência local (localStorage)
// ================================================================
const Storage = (() => {
    const PREFIX = 'aid_';

    function set(key, val) {
        try { localStorage.setItem(PREFIX + key, JSON.stringify(val)); } catch(e) {}
    }

    function get(key, fallback = null) {
        try {
            const v = localStorage.getItem(PREFIX + key);
            return v !== null ? JSON.parse(v) : fallback;
        } catch(e) { return fallback; }
    }

    function remove(key) {
        try { localStorage.removeItem(PREFIX + key); } catch(e) {}
    }

    function clear() {
        try {
            Object.keys(localStorage)
                .filter(k => k.startsWith(PREFIX))
                .forEach(k => localStorage.removeItem(k));
        } catch(e) {}
    }

    return { set, get, remove, clear };
})();

window.Storage = Storage;
