// ================================================================
// SUPABASE CONFIGURAÇÃO — Mercado Digital AID
// ================================================================
const SUPABASE_URL      = 'https://wobkjhctkibyobjhwemq.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable__95RWA9aTP9TdcCDBSSFHA_Y7GR-_U0';

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
        autoRefreshToken  : true,
        persistSession    : true,
        detectSessionInUrl: true
    }
});

window.SUPABASE_CONFIG = {
    client  : supabaseClient,
    url     : SUPABASE_URL,
    anonKey : SUPABASE_ANON_KEY,
    buckets : {
        PROFILES  : 'profile-images',
        PRODUCTS  : 'product-images',
        RECEIPTS  : 'receipt-images',
        DOCUMENTS : 'document-files',
        CHAT      : 'chat-images'
    },
    ORG_NAME : 'AID Group',
    TAX_RATE : 0.05 // 5% taxa de plataforma
};

console.info('[Mercado AID] Supabase conectado:', SUPABASE_URL);
