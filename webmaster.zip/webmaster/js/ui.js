// ================================================================
// ui.js — Componentes de interface
// Toasts, Modais, Loading, Confirmações
// ================================================================
const UI = (() => {

    // ── LOADING ──────────────────────────────────────────────
    function showLoading(msg = 'Aguarde…') {
        const el = document.getElementById('loadingOverlay');
        document.getElementById('loadingMessage').textContent = msg;
        if (el) el.classList.add('show');
    }

    function hideLoading() {
        const el = document.getElementById('loadingOverlay');
        if (el) el.classList.remove('show');
    }

    // ── TOASTS ───────────────────────────────────────────────
    const ICONS = { success:'fa-check-circle', error:'fa-times-circle', warning:'fa-exclamation-triangle', info:'fa-info-circle' };

    function toast(msg, type = 'info', duration = 3500) {
        let container = document.getElementById('toastContainer');
        if (!container) return;
        const t = document.createElement('div');
        t.className = `toast ${type}`;
        t.innerHTML = `
            <i class="fas ${ICONS[type] || ICONS.info} toast-icon"></i>
            <span class="toast-msg">${msg}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>`;
        container.appendChild(t);
        requestAnimationFrame(() => t.classList.add('show'));
        setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, duration);
    }

    // ── MODAL GENÉRICO ────────────────────────────────────────
    function modal({ title = '', body = '', footer = '', id = 'genericModal' } = {}) {
        let el = document.getElementById(id);
        if (el) el.remove();
        el = document.createElement('div');
        el.className = 'modal-overlay show';
        el.id = id;
        el.innerHTML = `
            <div class="modal-box">
                <div class="modal-handle"></div>
                <div class="modal-header">
                    <span class="modal-title">${title}</span>
                    <button class="icon-btn" onclick="document.getElementById('${id}').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">${body}</div>
                ${footer ? `<div class="modal-footer">${footer}</div>` : ''}
            </div>`;
        document.body.appendChild(el);
        el.addEventListener('click', e => { if (e.target === el) el.remove(); });
        return el;
    }

    function closeModal(id = 'genericModal') {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    // ── CONFIRMAÇÃO ───────────────────────────────────────────
    function confirm(msg, onConfirm, onCancel) {
        const el = modal({
            id: 'confirmModal',
            title: 'Confirmar',
            body: `<p>${msg}</p>`,
            footer: `
                <button class="btn btn-secondary btn-sm" id="confirmNo">Cancelar</button>
                <button class="btn btn-danger btn-sm" id="confirmYes">Confirmar</button>`
        });
        el.querySelector('#confirmNo').onclick  = () => { el.remove(); if (onCancel) onCancel(); };
        el.querySelector('#confirmYes').onclick = () => { el.remove(); if (onConfirm) onConfirm(); };
    }

    // ── PÁGINA DE ERRO ────────────────────────────────────────
    function errorPage(msg = 'Erro ao carregar') {
        return `
            <div class="empty-state">
                <i class="fas fa-exclamation-circle text-red"></i>
                <p>${msg}</p>
                <button class="btn btn-primary btn-sm mt-3" onclick="App.navigate('home')">
                    Voltar ao início
                </button>
            </div>`;
    }

    // ── ESTADO VAZIO ──────────────────────────────────────────
    function emptyState(icon, msg, btnLabel, btnAction) {
        return `
            <div class="empty-state">
                <i class="${icon}"></i>
                <p>${msg}</p>
                ${btnLabel ? `<button class="btn btn-primary btn-sm" onclick="${btnAction}">${btnLabel}</button>` : ''}
            </div>`;
    }

    // ── AVATAR ────────────────────────────────────────────────
    function avatarHtml(url, name = '?', cls = 'avatar-md') {
        if (url) return `<img src="${url}" class="avatar ${cls}" onerror="this.outerHTML='<div class=\'avatar ${cls}\'><i class=\'fas fa-user\'></i></div>'">`;
        const initial = (name || '?')[0].toUpperCase();
        return `<div class="avatar ${cls}" style="background:var(--blue-light);color:var(--blue);font-weight:700;">${initial}</div>`;
    }

    // ── ESCAPE HTML ───────────────────────────────────────────
    function esc(str) {
        if (!str) return '';
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    // ── FORMAT CURRENCY ───────────────────────────────────────
    function currency(val) {
        if (val == null) return '0,00 MT';
        return Number(val).toLocaleString('pt-MZ', { minimumFractionDigits: 2 }) + ' MT';
    }

    // ── FORMAT DATE ───────────────────────────────────────────
    function dateStr(iso) {
        if (!iso) return '';
        return new Date(iso).toLocaleDateString('pt-MZ', { day:'2-digit', month:'2-digit', year:'numeric' });
    }

    function timeAgo(iso) {
        if (!iso) return '';
        const diff = (Date.now() - new Date(iso)) / 1000;
        if (diff < 60)   return 'Agora mesmo';
        if (diff < 3600) return `${Math.floor(diff/60)} min atrás`;
        if (diff < 86400)return `${Math.floor(diff/3600)}h atrás`;
        return `${Math.floor(diff/86400)} dias atrás`;
    }

    function timeOnPlatform(iso) {
        if (!iso) return 'pouco tempo';
        const diff = (Date.now() - new Date(iso)) / 1000;
        const days  = Math.floor(diff / 86400);
        const months= Math.floor(days / 30);
        const years = Math.floor(days / 365);
        if (years >= 1)  return years  + (years  === 1 ? ' ano'  : ' anos');
        if (months >= 1) return months + (months === 1 ? ' mês'  : ' meses');
        if (days >= 1)   return days   + (days   === 1 ? ' dia'  : ' dias');
        return 'menos de 1 dia';
    }

    return { showLoading, hideLoading, toast, modal, closeModal, confirm, errorPage, emptyState, avatarHtml, esc, currency, dateStr, timeAgo, timeOnPlatform };
})();

window.UI = UI;
