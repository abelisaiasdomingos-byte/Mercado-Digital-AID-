// ================================================================
// wallet.js — Carteira Digital (Comprovantes de Pagamento)
// ================================================================
const Wallet = (() => {
    const db = () => window.SUPABASE_CONFIG.client;

    async function render() {
        if (!Auth.isLoggedIn()) return Auth.renderLogin();
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data: receipts } = await db().from('payment_receipts')
                .select('*, sender:sender_id(name, avatar_url), receiver:receiver_id(name, avatar_url)')
                .or(`sender_id.eq.${uid},receiver_id.eq.${uid}`)
                .order('created_at', { ascending: false });

            c.innerHTML = `
            <div class="flex-between mb-4">
                <h2 class="page-title" style="margin:0;">Carteira Digital</h2>
                <button class="btn btn-primary btn-sm" onclick="Wallet.renderSendReceipt()">
                    <i class="fas fa-plus"></i> Enviar comprovante
                </button>
            </div>

            <div class="tabs">
                <button class="tab-btn active" onclick="Wallet._filterTab('all',this)">Todos</button>
                <button class="tab-btn" onclick="Wallet._filterTab('sent',this)">Enviados</button>
                <button class="tab-btn" onclick="Wallet._filterTab('received',this)">Recebidos</button>
            </div>

            <div id="receiptsList">
            ${(receipts || []).length ? (receipts || []).map(r => receiptCardHtml(r, uid)).join('')
                : UI.emptyState('fas fa-receipt', 'Ainda não tem comprovantes.', 'Enviar comprovante', "Wallet.renderSendReceipt()")}
            </div>`;

            window._allReceipts = receipts || [];
            window._currentUid  = uid;
        } catch(e) {
            c.innerHTML = UI.errorPage('Erro ao carregar carteira');
        }
    }

    function receiptCardHtml(r, uid) {
        const isSender = r.sender_id === uid;
        const other    = isSender ? r.receiver : r.sender;
        const statusMap = { pending: 'pending', confirmed: 'confirmed', rejected: 'cancelled' };
        const statusLabel = { pending: 'Aguarda confirmação', confirmed: 'Confirmado', rejected: 'Rejeitado' };
        return `
        <div class="receipt-card" data-type="${isSender ? 'sent' : 'received'}">
            <img src="${r.image_url}" class="receipt-img" alt="Comprovante" onclick="Wallet.viewImage('${r.image_url}')">
            <div class="receipt-body">
                <div class="flex-between mb-2">
                    <div style="display:flex;gap:8px;align-items:center;">
                        ${UI.avatarHtml(other?.avatar_url, other?.name, 'avatar-sm')}
                        <div>
                            <p style="font-weight:600;font-size:.85rem;">${UI.esc(other?.name || 'Utilizador')}</p>
                            <p class="text-xs text-muted">${isSender ? 'Enviado para' : 'Recebido de'} • ${UI.timeAgo(r.created_at)}</p>
                        </div>
                    </div>
                    <span class="status status-${statusMap[r.status] || 'pending'}">${statusLabel[r.status] || 'Pendente'}</span>
                </div>
                ${r.amount ? `<p class="font-bold text-blue">${UI.currency(r.amount)}</p>` : ''}
                ${r.method ? `<p class="text-sm text-muted"><i class="fas fa-mobile-alt"></i> ${UI.esc(r.method)}</p>` : ''}
                ${r.caption ? `<p class="text-sm mt-2">${UI.esc(r.caption)}</p>` : ''}
                ${r.details ? `<p class="text-xs text-muted mt-1">${UI.esc(r.details)}</p>` : ''}
                ${!isSender && r.status === 'pending' ? `
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px;">
                    <button class="btn btn-success btn-sm" onclick="Wallet.confirmReceipt('${r.id}','confirmed')">
                        <i class="fas fa-check"></i> Confirmar
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="Wallet.confirmReceipt('${r.id}','rejected')">
                        <i class="fas fa-times"></i> Rejeitar
                    </button>
                </div>` : ''}
            </div>
        </div>`;
    }

    function _filterTab(type, btn) {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const list = document.getElementById('receiptsList');
        if (!list) return;
        const uid = window._currentUid;
        let filtered = window._allReceipts || [];
        if (type === 'sent')     filtered = filtered.filter(r => r.sender_id === uid);
        if (type === 'received') filtered = filtered.filter(r => r.receiver_id === uid);
        list.innerHTML = filtered.length ? filtered.map(r => receiptCardHtml(r, uid)).join('')
            : UI.emptyState('fas fa-receipt', 'Sem comprovantes nesta categoria.', '', '');
    }

    async function renderSendReceipt() {
        UI.modal({
            id: 'sendReceiptModal',
            title: 'Enviar Comprovante',
            body: `
                <div class="form-group">
                    <label class="form-label">Email do destinatário *</label>
                    <input type="email" id="receiptTo" class="form-input" placeholder="comerciante@email.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Foto do comprovante *</label>
                    <input type="file" id="receiptImg" class="form-input" accept="image/*">
                </div>
                <div class="form-group">
                    <label class="form-label">Valor pago (MT)</label>
                    <input type="number" id="receiptAmount" class="form-input" placeholder="0.00" min="0">
                </div>
                <div class="form-group">
                    <label class="form-label">Método de pagamento</label>
                    <select id="receiptMethod" class="form-input">
                        <option value="M-Pesa">M-Pesa</option>
                        <option value="e-Mola">e-Mola</option>
                        <option value="M-Cash">M-Cash</option>
                        <option value="Banco">Transferência Bancária</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Legenda / Nota</label>
                    <input type="text" id="receiptCaption" class="form-input" placeholder="Ex: Pagamento do pedido AID-202506-001">
                </div>
                <div class="form-group">
                    <label class="form-label">Detalhes adicionais</label>
                    <textarea id="receiptDetails" class="form-input" placeholder="Número de transacção, referência…"></textarea>
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal('sendReceiptModal')">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Wallet.sendReceipt()">
                    <i class="fas fa-paper-plane"></i> Enviar
                </button>`
        });
    }

    async function sendReceipt() {
        const toEmail  = document.getElementById('receiptTo')?.value?.trim();
        const file     = document.getElementById('receiptImg')?.files?.[0];
        const amount   = parseFloat(document.getElementById('receiptAmount')?.value) || null;
        const method   = document.getElementById('receiptMethod')?.value;
        const caption  = document.getElementById('receiptCaption')?.value?.trim();
        const details  = document.getElementById('receiptDetails')?.value?.trim();

        if (!toEmail) return UI.toast('Insira o email do destinatário', 'warning');
        if (!file)    return UI.toast('Seleccione uma foto do comprovante', 'warning');
        if (file.size > 10 * 1024 * 1024) return UI.toast('Imagem muito grande (máx. 10MB)', 'warning');

        UI.showLoading('A enviar comprovante…');
        try {
            // Buscar destinatário pelo email
            const { data: users } = await db().from('users').select('id').eq('id',
                (await db().auth.admin?.getUserByEmail?.(toEmail))?.data?.user?.id || ''
            );
            // Alternativa: buscar por auth.users via RPC ou usar email directamente
            const { data: authUsers } = await db().rpc('get_user_id_by_email', { email: toEmail }).catch(() => ({ data: null }));
            let receiverId = authUsers;

            if (!receiverId) {
                // Tentar encontrar pelo campo email na tabela users
                const { data: found } = await db().from('users').select('id').ilike('id',
                    (await db().auth.getUser())?.data?.user?.id || 'none'
                ).limit(1);
                if (!found?.length) {
                    UI.toast('Utilizador não encontrado com esse email', 'error');
                    UI.hideLoading(); return;
                }
                receiverId = found[0].id;
            }

            const uid  = Auth.getSession().user.id;
            const path = `receipts/${uid}/${Date.now()}.${file.name.split('.').pop()}`;
            const { error: upErr } = await db().storage.from('receipt-images').upload(path, file);
            if (upErr) throw upErr;
            const { data: { publicUrl } } = db().storage.from('receipt-images').getPublicUrl(path);

            const { error } = await db().from('payment_receipts').insert({
                sender_id: uid, receiver_id: receiverId,
                image_url: publicUrl, amount, method, caption, details, status: 'pending'
            });
            if (error) throw error;

            UI.closeModal('sendReceiptModal');
            UI.toast('Comprovante enviado!', 'success');
            render();
        } catch(e) {
            UI.toast('Erro: ' + (e.message || 'Verifique o email do destinatário'), 'error');
        } finally { UI.hideLoading(); }
    }

    async function confirmReceipt(id, status) {
        UI.showLoading('A processar…');
        try {
            const { error } = await db().from('payment_receipts').update({ status, confirmed_at: new Date().toISOString() }).eq('id', id);
            if (error) throw error;
            UI.toast(status === 'confirmed' ? 'Pagamento confirmado!' : 'Comprovante rejeitado', status === 'confirmed' ? 'success' : 'warning');
            render();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    function viewImage(url) {
        UI.modal({
            title: 'Comprovante',
            body: `<img src="${url}" style="width:100%;border-radius:8px;" alt="Comprovante">`
        });
    }

    // ── TAXA DE PLATAFORMA (só para comerciantes) ─────────────
    async function renderPlatformFee() {
        if (!Auth.isMerchant()) return document.getElementById('mainContent').innerHTML = UI.errorPage('Acesso negado');
        const c = document.getElementById('mainContent');
        c.innerHTML = `<div class="flex-center" style="height:30vh;"><div class="spinner"></div></div>`;
        try {
            const uid = Auth.getSession().user.id;
            const { data: fees } = await db().from('platform_fees')
                .select('*').eq('merchant_id', uid).order('created_at', { ascending: false });
            const taxRate = (window.SUPABASE_CONFIG.TAX_RATE || 0.05) * 100;

            c.innerHTML = `
            <div class="flex-between mb-4">
                <h2 class="page-title" style="margin:0;">Taxa AID Group</h2>
                <button class="btn btn-primary btn-sm" onclick="Wallet.renderSendFee()">
                    <i class="fas fa-plus"></i> Pagar taxa
                </button>
            </div>
            <div class="card mb-3" style="background:var(--blue-light);border:1.5px solid var(--blue);">
                <p class="text-blue font-bold"><i class="fas fa-info-circle"></i> Informação</p>
                <p class="text-sm mt-2">A taxa de plataforma é de <strong>${taxRate}%</strong> sobre cada venda efectuada. Efectue o pagamento via M-Pesa, e-Mola ou M-Cash para a conta <strong>AID Group</strong> e envie o comprovante aqui.</p>
            </div>
            <p class="section-title">Histórico de Pagamentos</p>
            ${(fees || []).length ? (fees || []).map(f => `
            <div class="receipt-card">
                ${f.image_url ? `<img src="${f.image_url}" class="receipt-img" onclick="Wallet.viewImage('${f.image_url}')">` : ''}
                <div class="receipt-body">
                    <div class="flex-between">
                        <span class="font-bold text-blue">${UI.currency(f.amount)}</span>
                        <span class="status status-${f.status === 'confirmed' ? 'confirmed' : f.status === 'rejected' ? 'cancelled' : 'pending'}">
                            ${f.status === 'confirmed' ? 'Confirmado' : f.status === 'rejected' ? 'Rejeitado' : 'Aguarda confirmação'}
                        </span>
                    </div>
                    ${f.caption ? `<p class="text-sm mt-1">${UI.esc(f.caption)}</p>` : ''}
                    <p class="text-xs text-muted mt-1">${UI.dateStr(f.created_at)}</p>
                </div>
            </div>`).join('')
            : UI.emptyState('fas fa-hand-holding-usd', 'Sem pagamentos registados.', '', '')}`;
        } catch(e) { c.innerHTML = UI.errorPage(); }
    }

    async function renderSendFee() {
        UI.modal({
            id: 'sendFeeModal',
            title: 'Pagar Taxa AID Group',
            body: `
                <div class="card mb-3" style="background:var(--blue-light);">
                    <p class="text-sm text-blue">Envie o pagamento para a conta AID Group e faça upload do comprovante abaixo.</p>
                </div>
                <div class="form-group">
                    <label class="form-label">Valor pago (MT) *</label>
                    <input type="number" id="feeAmount" class="form-input" placeholder="0.00" min="0">
                </div>
                <div class="form-group">
                    <label class="form-label">Foto do comprovante *</label>
                    <input type="file" id="feeImg" class="form-input" accept="image/*">
                </div>
                <div class="form-group">
                    <label class="form-label">Referência do pedido (opcional)</label>
                    <input type="text" id="feeCaption" class="form-input" placeholder="Ex: AID-202506-001">
                </div>`,
            footer: `
                <button class="btn btn-secondary btn-sm" onclick="UI.closeModal('sendFeeModal')">Cancelar</button>
                <button class="btn btn-primary btn-sm" onclick="Wallet.submitFee()">
                    <i class="fas fa-paper-plane"></i> Enviar
                </button>`
        });
    }

    async function submitFee() {
        const amount  = parseFloat(document.getElementById('feeAmount')?.value);
        const file    = document.getElementById('feeImg')?.files?.[0];
        const caption = document.getElementById('feeCaption')?.value?.trim();
        if (!amount || isNaN(amount)) return UI.toast('Insira o valor pago', 'warning');
        if (!file) return UI.toast('Seleccione o comprovante', 'warning');
        UI.showLoading('A enviar…');
        try {
            const uid  = Auth.getSession().user.id;
            const path = `fees/${uid}/${Date.now()}.${file.name.split('.').pop()}`;
            const { error: upErr } = await db().storage.from('receipt-images').upload(path, file);
            if (upErr) throw upErr;
            const { data: { publicUrl } } = db().storage.from('receipt-images').getPublicUrl(path);
            const { error } = await db().from('platform_fees').insert({ merchant_id: uid, amount, image_url: publicUrl, caption, status: 'pending' });
            if (error) throw error;
            UI.closeModal('sendFeeModal');
            UI.toast('Taxa enviada para confirmação!', 'success');
            renderPlatformFee();
        } catch(e) { UI.toast('Erro: ' + e.message, 'error'); }
        finally { UI.hideLoading(); }
    }

    return { render, renderSendReceipt, sendReceipt, confirmReceipt, viewImage, _filterTab, renderPlatformFee, renderSendFee, submitFee };
})();

window.Wallet = Wallet;
