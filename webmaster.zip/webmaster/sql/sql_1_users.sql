-- PARTE 1: Extensões + Utilizadores
-- Mercado Digital AID — AID Group
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS public.users (
    id          UUID         PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name        VARCHAR(200) NOT NULL,
    phone       VARCHAR(20),
    user_type   VARCHAR(20)  NOT NULL DEFAULT 'customer',
    avatar_url  TEXT,
    bio         TEXT,
    location    VARCHAR(200),
    specialty   VARCHAR(200),
    language    VARCHAR(10)  NOT NULL DEFAULT 'pt',
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.merchants (
    id                UUID         PRIMARY KEY REFERENCES public.users(id) ON DELETE CASCADE,
    store_name        VARCHAR(200),
    store_description TEXT,
    store_logo        TEXT,
    store_banner      TEXT,
    is_verified       BOOLEAN      NOT NULL DEFAULT false,
    rating            NUMERIC(3,2) NOT NULL DEFAULT 0,
    total_sales       INTEGER      NOT NULL DEFAULT 0,
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.categories (
    id         SERIAL       PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    icon       VARCHAR(50),
    parent_id  INTEGER      REFERENCES public.categories(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
