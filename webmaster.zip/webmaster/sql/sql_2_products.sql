-- PARTE 2: Produtos
CREATE TABLE IF NOT EXISTS public.products (
    id              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id     UUID          NOT NULL REFERENCES public.merchants(id) ON DELETE CASCADE,
    name            VARCHAR(200)  NOT NULL,
    description     TEXT,
    category_id     INTEGER       REFERENCES public.categories(id) ON DELETE SET NULL,
    price           NUMERIC(12,2) NOT NULL,
    quantity        INTEGER       NOT NULL DEFAULT 0,
    condition       VARCHAR(20),
    location        VARCHAR(200),
    delivery_method TEXT,
    status          VARCHAR(20)   NOT NULL DEFAULT 'active',
    views           INTEGER       NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.product_images (
    id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID        NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    image_url  TEXT        NOT NULL,
    is_primary BOOLEAN     NOT NULL DEFAULT false,
    position   INTEGER     NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.favorites (
    id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    product_id UUID        NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, product_id)
);

CREATE TABLE IF NOT EXISTS public.cart (
    id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    product_id UUID        NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    quantity   INTEGER     NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, product_id)
);
