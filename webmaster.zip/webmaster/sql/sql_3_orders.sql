-- PARTE 3: Pedidos
CREATE TABLE IF NOT EXISTS public.orders (
    id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID          NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    merchant_id      UUID          REFERENCES public.merchants(id) ON DELETE SET NULL,
    order_number     VARCHAR(50)   UNIQUE,
    total_amount     NUMERIC(12,2) NOT NULL,
    platform_fee     NUMERIC(12,2) NOT NULL DEFAULT 0,
    status           VARCHAR(30)   NOT NULL DEFAULT 'pending',
    payment_method   VARCHAR(50),
    shipping_address TEXT          NOT NULL,
    tracking_code    VARCHAR(100),
    notes            TEXT,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.order_items (
    id           UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id     UUID          NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id   UUID          REFERENCES public.products(id) ON DELETE SET NULL,
    product_name VARCHAR(200)  NOT NULL,
    quantity     INTEGER       NOT NULL,
    unit_price   NUMERIC(12,2) NOT NULL,
    created_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.delivery_tracking (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id    UUID        NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    status      VARCHAR(50),
    location    VARCHAR(200),
    description TEXT,
    updated_by  UUID        REFERENCES public.users(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
