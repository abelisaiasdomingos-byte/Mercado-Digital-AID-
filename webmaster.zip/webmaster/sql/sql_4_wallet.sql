-- PARTE 4: Carteira Digital (Comprovantes) + Taxa AID Group
CREATE TABLE IF NOT EXISTS public.payment_receipts (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id      UUID        REFERENCES public.orders(id) ON DELETE SET NULL,
    sender_id     UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    receiver_id   UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    amount        NUMERIC(12,2),
    method        VARCHAR(50),
    image_url     TEXT        NOT NULL,
    caption       TEXT,
    details       TEXT,
    status        VARCHAR(20) NOT NULL DEFAULT 'pending',
    confirmed_at  TIMESTAMPTZ,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.platform_fees (
    id            UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id   UUID          NOT NULL REFERENCES public.merchants(id) ON DELETE CASCADE,
    order_id      UUID          REFERENCES public.orders(id) ON DELETE SET NULL,
    amount        NUMERIC(12,2) NOT NULL,
    image_url     TEXT,
    caption       TEXT,
    status        VARCHAR(20)   NOT NULL DEFAULT 'pending',
    confirmed_at  TIMESTAMPTZ,
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);
