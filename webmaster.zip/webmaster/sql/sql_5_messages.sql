-- PARTE 5: Mensagens + Notificações + Documentos
CREATE TABLE IF NOT EXISTS public.messages (
    id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id VARCHAR(100) NOT NULL,
    sender_id       UUID         NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    receiver_id     UUID         NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    message         TEXT,
    image_url       TEXT,
    original_lang   VARCHAR(10),
    is_read         BOOLEAN      NOT NULL DEFAULT false,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.notifications (
    id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID         NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    title        VARCHAR(200) NOT NULL,
    message      TEXT,
    type         VARCHAR(50),
    reference_id TEXT,
    is_read      BOOLEAN      NOT NULL DEFAULT false,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.documents (
    id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID         NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    name          VARCHAR(200) NOT NULL,
    document_type VARCHAR(50),
    file_url      TEXT         NOT NULL,
    is_verified   BOOLEAN      NOT NULL DEFAULT false,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_conv    ON public.messages(conversation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notif_user       ON public.notifications(user_id, is_read, created_at DESC);
