-- PARTE 6: Contratos + Disputas + Avaliações
CREATE TABLE IF NOT EXISTS public.contracts (
    id                 UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id           UUID        REFERENCES public.orders(id) ON DELETE SET NULL,
    user_id            UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    merchant_id        UUID        REFERENCES public.merchants(id) ON DELETE SET NULL,
    terms              TEXT,
    signed_by_user     BOOLEAN     NOT NULL DEFAULT false,
    signed_by_merchant BOOLEAN     NOT NULL DEFAULT false,
    signed_at          TIMESTAMPTZ,
    file_url           TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.disputes (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id      UUID        REFERENCES public.orders(id) ON DELETE SET NULL,
    user_id       UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    merchant_id   UUID        REFERENCES public.merchants(id) ON DELETE SET NULL,
    subject       VARCHAR(200),
    description   TEXT,
    status        VARCHAR(20) NOT NULL DEFAULT 'open',
    resolution    TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.reviews (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    reviewer_id UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    target_id   UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    order_id    UUID        REFERENCES public.orders(id) ON DELETE SET NULL,
    rating      SMALLINT    NOT NULL,
    comment     TEXT,
    type        VARCHAR(30),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
